import React, { useState } from 'react';
import { OBDORecord } from '../types';
import { Table, ShieldCheck, ChevronDown, ChevronRight, Layers, Building, Store, Truck } from 'lucide-react';

interface PivotViewProps {
  records: OBDORecord[];
}

export const PivotView: React.FC<PivotViewProps> = ({ records }) => {
  const [activePivotSection, setActivePivotSection] = useState<'brand' | 'bu' | 'shipto' | 'custom'>('brand');

  // --- Pivot 1 Data: Brand & Business Scenario ---
  const brandPivotMap = new Map<
    string,
    {
      brand: string;
      scenarios: Set<string>;
      ewmQty: number;
      packedQty: number;
      dpQty: number;
      dnQty: number;
      apparel: number;
      footwear: number;
      accessories: number;
      equipment: number;
      cartons: number;
      obdoCount: number;
    }
  >();

  records.forEach((r) => {
    const key = r.brand || 'Unassigned';
    const curr = brandPivotMap.get(key) || {
      brand: key,
      scenarios: new Set(),
      ewmQty: 0,
      packedQty: 0,
      dpQty: 0,
      dnQty: 0,
      apparel: 0,
      footwear: 0,
      accessories: 0,
      equipment: 0,
      cartons: 0,
      obdoCount: 0,
    };

    if (r.businessScenario) curr.scenarios.add(r.businessScenario);
    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.packedQty += Number(r.packedQty) || 0;
    curr.dpQty += Number(r.dpTotalQty) || 0;
    curr.dnQty += Number(r.dnTotalQty) || 0;
    curr.apparel += Number(r.apparel) || 0;
    curr.footwear += Number(r.footwear) || 0;
    curr.accessories += Number(r.accessories) || 0;
    curr.equipment += Number(r.equipment) || 0;
    curr.cartons += Number(r.numberOfCartons) || 0;
    curr.obdoCount += 1;

    brandPivotMap.set(key, curr);
  });

  const brandPivotRows = Array.from(brandPivotMap.values());

  // --- Pivot 2 Data: Business Unit, Store Grade & CAP ---
  const buPivotMap = new Map<
    string,
    {
      key: string;
      businessUnit: string;
      storeGrade: string;
      deliveryTime: string;
      frequency: string;
      capSum: number;
      weeklyCapSum: number;
      ewmQty: number;
      packedQty: number;
      count: number;
    }
  >();

  records.forEach((r) => {
    const key = `${r.businessUnit || 'General'}-${r.storeGrade || 'N/A'}`;
    const curr = buPivotMap.get(key) || {
      key,
      businessUnit: r.businessUnit || 'General',
      storeGrade: r.storeGrade || 'N/A',
      deliveryTime: r.deliveryTime || 'Standard',
      frequency: r.frequency || 'Regular',
      capSum: 0,
      weeklyCapSum: 0,
      ewmQty: 0,
      packedQty: 0,
      count: 0,
    };

    curr.capSum += Number(r.cap) || 0;
    curr.weeklyCapSum += Number(r.weeklyCap) || 0;
    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.packedQty += Number(r.packedQty) || 0;
    curr.count += 1;

    buPivotMap.set(key, curr);
  });

  const buPivotRows = Array.from(buPivotMap.values());

  // --- Pivot 3 Data: Ship-To Party & Goods Issue Timeline ---
  const shipToPivotMap = new Map<
    string,
    {
      shipToDesc: string;
      whseProcType: string;
      goodsIssueDate: string;
      omniLmd: string;
      ewmQty: number;
      packedQty: number;
      cartons: number;
      count: number;
    }
  >();

  records.forEach((r) => {
    const desc = r.shipToPartyDescription || r.shipTo || 'Unknown Store';
    const curr = shipToPivotMap.get(desc) || {
      shipToDesc: desc,
      whseProcType: r.whseProcType || '2012',
      goodsIssueDate: r.goodsIssueStatusDate || 'Pending',
      omniLmd: r.omniActualLmd || '#N/A',
      ewmQty: 0,
      packedQty: 0,
      cartons: 0,
      count: 0,
    };

    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.packedQty += Number(r.packedQty) || 0;
    curr.cartons += Number(r.numberOfCartons) || 0;
    curr.count += 1;

    shipToPivotMap.set(desc, curr);
  });

  const shipToPivotRows = Array.from(shipToPivotMap.values());

  return (
    <div className="space-y-6">
      {/* Top Banner: Collision Protection Notice & Tabs */}
      <div className="bg-white border border-[#E2E8F0] rounded p-4 text-[#1A1C1E] flex flex-wrap items-center justify-between gap-4 shadow-2xs">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-[#1A1C1E] rounded text-white shadow-2xs">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xs font-bold tracking-wider uppercase text-slate-900 font-mono">
              DYNAMIC PIVOT TABLE SUMMARIES (REAL-TIME)
            </h2>
            <p className="text-[10px] text-slate-500 font-mono">
              Summarizing Brand, Business Unit, Ship-To, Whse Proc Type, CAP, and Quantities
            </p>
          </div>
        </div>

        {/* Pivot Navigation Buttons */}
        <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded border border-slate-200 font-mono">
          <button
            onClick={() => setActivePivotSection('brand')}
            className={`px-3 py-1.5 text-xs font-bold rounded cursor-pointer transition-all ${
              activePivotSection === 'brand'
                ? 'bg-[#2E5BFF] text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Brand & Scenario
          </button>
          <button
            onClick={() => setActivePivotSection('bu')}
            className={`px-3 py-1.5 text-xs font-bold rounded cursor-pointer transition-all ${
              activePivotSection === 'bu'
                ? 'bg-[#2E5BFF] text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            BU & Store CAP
          </button>
          <button
            onClick={() => setActivePivotSection('shipto')}
            className={`px-3 py-1.5 text-xs font-bold rounded cursor-pointer transition-all ${
              activePivotSection === 'shipto'
                ? 'bg-[#2E5BFF] text-white shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            Ship-To & Logistics
          </button>
        </div>
      </div>

      {/* --- Section 1: Brand & Scenario Pivot --- */}
      {activePivotSection === 'brand' && (
        <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs overflow-x-auto">
          <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#2E5BFF]" /> 1. Brand & Business Scenario Summary
            </h3>
            <span className="text-xs text-slate-500 font-mono font-bold">
              {brandPivotRows.length} Brand Groups
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse data-table">
            <thead>
              <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
                <th className="py-2.5 px-3 font-bold">Brand</th>
                <th className="py-2.5 px-3 font-bold">Business Scenarios</th>
                <th className="py-2.5 px-3 font-bold text-right">OBDO Count</th>
                <th className="py-2.5 px-3 font-bold text-right">EWM Item Total QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">Packed QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">DP Total Qty</th>
                <th className="py-2.5 px-3 font-bold text-right">DN Total Qty</th>
                <th className="py-2.5 px-3 font-bold text-right">Apparel</th>
                <th className="py-2.5 px-3 font-bold text-right">Footwear</th>
                <th className="py-2.5 px-3 font-bold text-right">Acc & Eq</th>
                <th className="py-2.5 px-3 font-bold text-right">Cartons</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {brandPivotRows.map((row) => (
                <tr key={row.brand} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{row.brand}</td>
                  <td className="py-2.5 px-3 text-slate-600">
                    {Array.from(row.scenarios).join(', ')}
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-slate-700">{row.obdoCount}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                    {row.ewmQty}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-green-600">
                    {row.packedQty}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{row.dpQty}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{row.dnQty}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-amber-600">
                    {row.apparel}
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-purple-600">
                    {row.footwear}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-600">
                    {row.accessories + row.equipment}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-slate-800">
                    {row.cartons}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
                <td className="py-2.5 px-3">GRAND TOTAL</td>
                <td className="py-2.5 px-3 text-slate-600">All Scenarios</td>
                <td className="py-2.5 px-3 text-right">
                  {brandPivotRows.reduce((acc, r) => acc + r.obdoCount, 0)}
                </td>
                <td className="py-2.5 px-3 text-right text-[#2E5BFF]">
                  {brandPivotRows.reduce((acc, r) => acc + r.ewmQty, 0)}
                </td>
                <td className="py-2.5 px-3 text-right text-green-600">
                  {brandPivotRows.reduce((acc, r) => acc + r.packedQty, 0)}
                </td>
                <td className="py-2.5 px-3 text-right">
                  {brandPivotRows.reduce((acc, r) => acc + r.dpQty, 0)}
                </td>
                <td className="py-2.5 px-3 text-right">
                  {brandPivotRows.reduce((acc, r) => acc + r.dnQty, 0)}
                </td>
                <td className="py-2.5 px-3 text-right text-amber-600">
                  {brandPivotRows.reduce((acc, r) => acc + r.apparel, 0)}
                </td>
                <td className="py-2.5 px-3 text-right text-purple-600">
                  {brandPivotRows.reduce((acc, r) => acc + r.footwear, 0)}
                </td>
                <td className="py-2.5 px-3 text-right">
                  {brandPivotRows.reduce(
                    (acc, r) => acc + r.accessories + r.equipment,
                    0
                  )}
                </td>
                <td className="py-2.5 px-3 text-right">
                  {brandPivotRows.reduce((acc, r) => acc + r.cartons, 0)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {/* --- Section 2: Business Unit, Store Grade & CAP --- */}
      {activePivotSection === 'bu' && (
        <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs overflow-x-auto">
          <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 font-mono flex items-center gap-2">
              <Store className="w-4 h-4 text-[#2E5BFF]" /> 2. Business Unit, Store Grade & CAP Summary
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              Store Capacity Analysis
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse data-table">
            <thead>
              <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
                <th className="py-2.5 px-3 font-bold">Business Unit</th>
                <th className="py-2.5 px-3 font-bold">Store Grade</th>
                <th className="py-2.5 px-3 font-bold">Delivery Time</th>
                <th className="py-2.5 px-3 font-bold">Frequency</th>
                <th className="py-2.5 px-3 font-bold text-right">EWM Item QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">Packed QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">Daily CAP</th>
                <th className="py-2.5 px-3 font-bold text-right">Weekly CAP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {buPivotRows.map((row) => (
                <tr key={row.key} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{row.businessUnit}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-700">
                    <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-300 font-bold">
                      Grade {row.storeGrade}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{row.deliveryTime}</td>
                  <td className="py-2.5 px-3 text-slate-600">{row.frequency}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                    {row.ewmQty}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-green-600">
                    {row.packedQty}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-800 font-medium">
                    {Math.round(row.capSum / (row.count || 1))}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-900 font-bold">
                    {Math.round(row.weeklyCapSum / (row.count || 1))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* --- Section 3: Ship-To & Logistics --- */}
      {activePivotSection === 'shipto' && (
        <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs overflow-x-auto">
          <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 font-mono flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#2E5BFF]" /> 3. Ship-To Party & Whse Proc. Type Summary
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              Delivery Logistics & OMNI LMD
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono border-collapse data-table">
            <thead>
              <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
                <th className="py-2.5 px-3 font-bold">Ship-To Party Description</th>
                <th className="py-2.5 px-3 font-bold">Whse Proc. Type</th>
                <th className="py-2.5 px-3 font-bold">Goods Issue Date</th>
                <th className="py-2.5 px-3 font-bold">OMNI Actual LMD</th>
                <th className="py-2.5 px-3 font-bold text-right">OBDO Count</th>
                <th className="py-2.5 px-3 font-bold text-right">EWM QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">Packed QTY</th>
                <th className="py-2.5 px-3 font-bold text-right">Cartons</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {shipToPivotRows.map((row) => (
                <tr key={row.shipToDesc} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-900">{row.shipToDesc}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-600">{row.whseProcType}</td>
                  <td className="py-2.5 px-3 text-slate-600">{row.goodsIssueDate}</td>
                  <td className="py-2.5 px-3 text-[#2E5BFF] font-mono">{row.omniLmd}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-slate-700">{row.count}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                    {row.ewmQty}
                  </td>
                  <td className="py-2.5 px-3 text-right font-semibold text-green-600">
                    {row.packedQty}
                  </td>
                  <td className="py-2.5 px-3 text-right font-medium text-slate-800">
                    {row.cartons}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
