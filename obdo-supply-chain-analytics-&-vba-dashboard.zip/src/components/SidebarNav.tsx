import React from 'react';
import {
  LayoutDashboard,
  TableProperties,
  Layers,
  Truck,
  FileSpreadsheet,
  FileCode,
  Database,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'pivots'
  | 'categories'
  | 'schedule'
  | 'datatable'
  | 'vba';

interface SidebarNavProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isCollapsed: boolean;
  setIsCollapsed: (val: boolean) => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  setActiveTab,
  isCollapsed,
  setIsCollapsed,
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Control Tower Overview',
      icon: LayoutDashboard,
      desc: 'KPI Cards & Real-time Charts',
    },
    {
      id: 'pivots',
      label: 'Pivot Summaries',
      icon: TableProperties,
      desc: 'Collapsible Multi-Field Summaries',
    },
    {
      id: 'categories',
      label: 'Product Categories',
      icon: Layers,
      desc: 'Apparel, Footwear, Acc & Eq',
    },
    {
      id: 'schedule',
      label: 'Store CAP & Delivery',
      icon: Truck,
      desc: 'Grade, Frequency & LMD',
    },
    {
      id: 'datatable',
      label: 'OBDO Raw Records',
      icon: Database,
      desc: 'Search & Inspect Raw Data',
    },
    {
      id: 'vba',
      label: 'VBA Code Engine',
      icon: FileCode,
      desc: 'Collision-Proof Macro Generator',
    },
  ];

  return (
    <aside
      className={`bg-white text-[#1A1C1E] flex flex-col transition-all duration-300 border-r border-[#E2E8F0] ${
        isCollapsed ? 'w-16' : 'w-64'
      } shrink-0`}
    >
      {/* Sidebar Header */}
      <div className="p-4 border-b border-[#E2E8F0] flex items-center justify-between">
        {!isCollapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded bg-[#1A1C1E] flex items-center justify-center font-mono font-bold text-white text-xs shadow-xs">
              EWM
            </div>
            <span className="font-bold text-xs tracking-wider text-slate-900 uppercase font-mono">
              Analytics Grid
            </span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 mx-auto cursor-pointer font-mono text-xs font-bold"
          title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {isCollapsed ? '→' : '←'}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as NavTab)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-100 text-[#1A1C1E] font-bold border-l-4 border-[#2E5BFF] shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 ${
                  isActive ? 'text-[#2E5BFF]' : 'text-slate-400'
                }`}
              />
              {!isCollapsed && (
                <div className="text-left overflow-hidden">
                  <div className="text-xs font-bold truncate leading-tight uppercase font-mono tracking-tight">
                    {item.label}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate font-normal">
                    {item.desc}
                  </div>
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Status / Preset Info & Branding */}
      {!isCollapsed && (
        <div className="p-3 m-2 bg-slate-50 rounded border border-[#E2E8F0] text-center font-mono">
          <div className="text-[10px] font-bold text-[#2E5BFF] uppercase tracking-wider">
            DESIGNED BY RONALD MPUUGA
          </div>
          <div className="text-[11px] font-bold text-slate-800 mt-1">
            <a
              href="https://mpuugasites.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#2E5BFF] hover:underline"
            >
              mpuugasites.com
            </a>
          </div>
          <div className="text-[10px] text-slate-500 mt-1 uppercase">
            All rights reserved
          </div>
        </div>
      )}
    </aside>
  );
};
