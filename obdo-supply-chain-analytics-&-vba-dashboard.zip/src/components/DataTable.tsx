import React, { useState } from 'react';
import { OBDORecord } from '../types';
import { Table, Search, ChevronLeft, ChevronRight, FileSpreadsheet } from 'lucide-react';

interface DataTableProps {
  records: OBDORecord[];
}

export const DataTable: React.FC<DataTableProps> = ({ records }) => {
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const totalPages = Math.ceil(records.length / pageSize) || 1;
  const startIndex = (page - 1) * pageSize;
  const currentRecords = records.slice(startIndex, startIndex + pageSize);

  return (
    <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs space-y-4 font-mono">
      <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-3">
        <div className="flex items-center space-x-2">
          <Table className="w-4 h-4 text-[#2E5BFF]" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            RAW OBDO LOGISTICS RECORDS ({records.length} TOTAL)
          </h3>
        </div>
        <div className="text-xs text-slate-500 font-bold">
          Showing {startIndex + 1}-{Math.min(startIndex + pageSize, records.length)} of{' '}
          {records.length}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse data-table">
          <thead>
            <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
              <th className="py-2.5 px-3 font-bold">Document (OBDO)</th>
              <th className="py-2.5 px-3 font-bold">ERP Doc</th>
              <th className="py-2.5 px-3 font-bold">Brand</th>
              <th className="py-2.5 px-3 font-bold">Business Scenario</th>
              <th className="py-2.5 px-3 font-bold">Ship-To Party Description</th>
              <th className="py-2.5 px-3 font-bold">Proc Type</th>
              <th className="py-2.5 px-3 font-bold text-right">EWM QTY</th>
              <th className="py-2.5 px-3 font-bold text-right">Packed QTY</th>
              <th className="py-2.5 px-3 font-bold text-right">Cartons</th>
              <th className="py-2.5 px-3 font-bold">Goods Issue Date</th>
              <th className="py-2.5 px-3 font-bold">Business Unit</th>
              <th className="py-2.5 px-3 font-bold">Store Grade</th>
              <th className="py-2.5 px-3 font-bold">Driver</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {currentRecords.map((r) => (
              <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                <td className="py-2.5 px-3 font-bold text-[#2E5BFF]">{r.obdo}</td>
                <td className="py-2.5 px-3 font-mono text-slate-600">{r.erpDocument}</td>
                <td className="py-2.5 px-3 font-bold text-slate-800">{r.brand}</td>
                <td className="py-2.5 px-3 text-slate-600">{r.businessScenario}</td>
                <td className="py-2.5 px-3 font-medium text-slate-900">
                  {r.shipToPartyDescription}
                </td>
                <td className="py-2.5 px-3 font-mono text-slate-600">{r.whseProcType}</td>
                <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                  {r.ewmObdoItemTotalQty}
                </td>
                <td className="py-2.5 px-3 text-right font-semibold text-green-600">
                  {r.packedQty}
                </td>
                <td className="py-2.5 px-3 text-right font-medium text-slate-800">
                  {r.numberOfCartons}
                </td>
                <td className="py-2.5 px-3 text-slate-600">{r.goodsIssueStatusDate}</td>
                <td className="py-2.5 px-3 text-slate-700">{r.businessUnit}</td>
                <td className="py-2.5 px-3 font-semibold text-slate-800">
                  <span className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-300">
                    Grade {r.storeGrade}
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-700">{r.driver}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between pt-2 border-t border-[#E2E8F0] text-xs text-slate-600">
        <button
          disabled={page <= 1}
          onClick={() => setPage(page - 1)}
          className="flex items-center space-x-1 px-3 py-1.5 rounded bg-slate-100 border border-slate-300 disabled:opacity-40 hover:bg-slate-200 cursor-pointer text-slate-800 font-bold transition-all"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span>Previous</span>
        </button>
        <span>
          Page <strong className="text-slate-900">{page}</strong> of{' '}
          <strong className="text-slate-900">{totalPages}</strong>
        </span>
        <button
          disabled={page >= totalPages}
          onClick={() => setPage(page + 1)}
          className="flex items-center space-x-1 px-3 py-1.5 rounded bg-slate-100 border border-slate-300 disabled:opacity-40 hover:bg-slate-200 cursor-pointer text-slate-800 font-bold transition-all"
        >
          <span>Next</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
