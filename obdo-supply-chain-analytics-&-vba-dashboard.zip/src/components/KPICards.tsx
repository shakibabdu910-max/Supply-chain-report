import React from 'react';
import { KPIStats } from '../types';
import {
  PackageCheck,
  Boxes,
  Truck,
  Shirt,
  Percent,
  CalendarCheck2,
  Building2,
  Layers,
} from 'lucide-react';

interface KPICardsProps {
  stats: KPIStats;
}

export const KPICards: React.FC<KPICardsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6 font-mono">
      {/* KPI 1: EWM OBDO Item Total QTY */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">EWM OBDO Item Total</span>
          <div className="p-1 bg-blue-50 text-[#2E5BFF] rounded border border-blue-200">
            <PackageCheck className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-slate-900">
            {stats.totalEwmQty.toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-500 font-bold">QTY</span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-[#2E5BFF]" style={{ width: '100%' }}></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Orders: {stats.totalOrders}</span>
          <span className="text-[#2E5BFF] font-semibold">100% ERP</span>
        </div>
      </div>

      {/* KPI 2: Packed QTY & Packing Completion */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">Packed QTY Completion</span>
          <div className="p-1 bg-green-50 text-green-600 rounded border border-green-200">
            <Percent className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-slate-900">
            {stats.totalPackedQty.toLocaleString()}
          </span>
          <span className="status-chip status-complete ml-1">
            {stats.packingCompletionRate.toFixed(1)}%
          </span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-green-600"
            style={{ width: `${Math.min(stats.packingCompletionRate, 100)}%` }}
          ></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>DP: {stats.totalDpQty}</span>
          <span>DN: {stats.totalDnQty}</span>
        </div>
      </div>

      {/* KPI 3: Business Unit Analysis */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">Business Units</span>
          <div className="p-1 bg-indigo-50 text-indigo-600 rounded border border-indigo-200">
            <Building2 className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-indigo-700">
            {stats.totalBusinessUnits}
          </span>
          <span className="text-[10px] text-slate-500 font-bold uppercase">Active BUs</span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-indigo-600" style={{ width: '100%' }}></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Top: <strong className="text-slate-800">{stats.topBusinessUnit}</strong></span>
        </div>
      </div>

      {/* KPI 4: OMNI Actual LMD Status */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">OMNI Actual LMD</span>
          <div className="p-1 bg-blue-50 text-[#2E5BFF] rounded border border-blue-200">
            <Truck className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-[#2E5BFF]">
            {stats.activeOmniLmdCount}
          </span>
          <span className="text-[10px] text-slate-500 font-bold">Scheduled</span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#2E5BFF]"
            style={{
              width: `${
                stats.totalOrders > 0
                  ? (stats.activeOmniLmdCount / stats.totalOrders) * 100
                  : 0
              }%`,
            }}
          ></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Pending (#N/A): {stats.pendingOmniLmdCount}</span>
        </div>
      </div>

      {/* KPI 5: Cartons & Pallets */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">Number of Cartons</span>
          <div className="p-1 bg-amber-50 text-amber-600 rounded border border-amber-200">
            <Boxes className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-slate-900">
            {stats.totalCartons.toLocaleString()}
          </span>
          <span className="text-[10px] text-slate-500 font-bold">CTNS</span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-amber-500" style={{ width: '85%' }}></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Pallets: {stats.totalPallets}</span>
          <span>{(stats.totalCartons / (stats.totalOrders || 1)).toFixed(1)}/doc</span>
        </div>
      </div>

      {/* KPI 6: GI Execution Status */}
      <div className="card bg-white border border-[#E2E8F0] rounded p-3 text-[#1A1C1E] shadow-2xs relative">
        <div className="flex items-center justify-between">
          <span className="kpi-label">GI Execution</span>
          <div className="p-1 bg-purple-50 text-purple-600 rounded border border-purple-200">
            <Shirt className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-1.5 flex items-baseline space-x-1">
          <span className="text-xl font-bold text-green-600">100%</span>
          <span className="status-chip status-complete">Ready</span>
        </div>
        <div className="mt-1.5 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-green-600" style={{ width: '100%' }}></div>
        </div>
        <div className="mt-1.5 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Apparel: {stats.totalApparel}</span>
          <span>Footwear: {stats.totalFootwear}</span>
        </div>
      </div>
    </div>
  );
};
