import React, { useState } from 'react';
import { generateVBAMacro } from '../utils/vbaGenerator';
import { FileCode, X, Copy, Check, Download, ShieldCheck, HelpCircle } from 'lucide-react';

interface VBAScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VBAScriptModal: React.FC<VBAScriptModalProps> = ({ isOpen, onClose }) => {
  const [spacing, setSpacing] = useState<number>(8);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const vbaCode = generateVBAMacro(spacing);

  const handleCopy = () => {
    navigator.clipboard.writeText(vbaCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([vbaCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `OBDO_Dashboard_Macro_Buffer_${spacing}.bas`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4 backdrop-blur-xs font-mono">
      <div className="bg-white border border-[#E2E8F0] text-[#1A1C1E] rounded w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-100 px-6 py-4 flex items-center justify-between border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <FileCode className="w-4 h-4 text-[#2E5BFF]" />
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                AUTOMATED VBA MACRO GENERATOR (COLLISION PROTECTION)
              </h3>
              <p className="text-[10px] text-slate-500 font-mono">
                Generates presentation-ready Excel VBA script with dynamic pivot table buffer spacing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-200 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Controls & Instructions */}
        <div className="p-4 bg-slate-50 border-b border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
          {/* Spacing Buffer Selector */}
          <div className="flex items-center space-x-2 bg-white px-3 py-1.5 rounded border border-slate-300">
            <ShieldCheck className="w-4 h-4 text-[#2E5BFF]" />
            <span className="font-bold text-slate-900">Pivot Safety Buffer:</span>
            <select
              value={spacing}
              onChange={(e) => setSpacing(Number(e.target.value))}
              className="bg-slate-100 text-[#2E5BFF] font-bold px-2 py-0.5 rounded border border-slate-300 focus:outline-none"
            >
              <option value={5}>5 Blank Rows</option>
              <option value={8}>8 Blank Rows (Recommended)</option>
              <option value={12}>12 Blank Rows (Large Data)</option>
              <option value={15}>15 Blank Rows (Maximum Safety)</option>
            </select>
          </div>

          <div className="text-slate-500 flex items-center space-x-1">
            <HelpCircle className="w-3.5 h-3.5 text-[#2E5BFF]" />
            <span>Guarantees Excel never throws "Pivot table report cannot overlap" errors.</span>
          </div>
        </div>

        {/* Code Editor Preview */}
        <div className="flex-1 p-4 overflow-y-auto bg-slate-900 font-mono text-[11px] leading-relaxed text-slate-100">
          <pre className="whitespace-pre-wrap">{vbaCode}</pre>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="bg-slate-50 p-4 border-t border-[#E2E8F0] text-[11px] text-slate-600 grid grid-cols-1 md:grid-cols-3 gap-2">
          <div className="bg-white p-2.5 rounded border border-slate-200">
            <span className="font-bold text-[#2E5BFF] block mb-0.5">Step 1: Open VBA Editor</span>
            In Excel, press <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-900 border border-slate-300 font-bold">Alt + F11</code> to open Microsoft Visual Basic.
          </div>
          <div className="bg-white p-2.5 rounded border border-slate-200">
            <span className="font-bold text-[#2E5BFF] block mb-0.5">Step 2: Insert Module</span>
            Click <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-900 border border-slate-300 font-bold">Insert → Module</code> and paste this code.
          </div>
          <div className="bg-white p-2.5 rounded border border-slate-200">
            <span className="font-bold text-[#2E5BFF] block mb-0.5">Step 3: Run Macro</span>
            Press <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-900 border border-slate-300 font-bold">F5</code> or run <code className="text-[#2E5BFF] font-bold">Build_Professional_OBDO_Dashboard</code>.
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-100 px-6 py-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#E2E8F0]">
          <div className="flex flex-col">
            <span className="text-xs text-slate-700 font-bold">
              Design by Ronald Mpuuga | All rights reserved by{' '}
              <a
                href="https://mpuugasites.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#2E5BFF] hover:underline"
              >
                mpuugasites.com
              </a>
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              VBA Macro Buffer: <strong className="text-slate-900">{spacing} Rows</strong>
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1.5 px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded border border-slate-300 cursor-pointer transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Code Copied!' : 'Copy VBA Code'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center space-x-1.5 px-4 py-2 bg-[#2E5BFF] hover:bg-blue-600 text-white text-xs font-bold rounded shadow-2xs border border-blue-500 cursor-pointer transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download .BAS Macro Script</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
