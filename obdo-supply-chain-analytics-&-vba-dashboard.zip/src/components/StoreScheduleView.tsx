import React from 'react';
import { OBDORecord } from '../types';
import { Truck, Store, Calendar, Clock, UserCheck, ShieldAlert } from 'lucide-react';

interface StoreScheduleViewProps {
  records: OBDORecord[];
}

export const StoreScheduleView: React.FC<StoreScheduleViewProps> = ({ records }) => {
  return (
    <div className="space-y-6">
      {/* Overview Table of Store CAP, Schedule & Drivers */}
      <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs overflow-x-auto font-mono">
        <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#2E5BFF]" />
            STORE GRADE, DELIVERY SCHEDULE & WEEKLY CAP ALLOCATION
          </h3>
          <span className="text-xs text-slate-500 font-bold">LOGISTICS DISPATCH</span>
        </div>

        <table className="w-full text-left text-xs border-collapse data-table">
          <thead>
            <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
              <th className="py-2.5 px-3 font-bold">Store / Ship-To Description</th>
              <th className="py-2.5 px-3 font-bold">Business Unit</th>
              <th className="py-2.5 px-3 font-bold">Store Grade</th>
              <th className="py-2.5 px-3 font-bold">Delivery Time</th>
              <th className="py-2.5 px-3 font-bold">Frequency</th>
              <th className="py-2.5 px-3 font-bold text-right">Daily CAP</th>
              <th className="py-2.5 px-3 font-bold text-right">Weekly CAP</th>
              <th className="py-2.5 px-3 font-bold">Driver / Vehicle</th>
              <th className="py-2.5 px-3 font-bold">Receiver</th>
              <th className="py-2.5 px-3 font-bold">OMNI LMD</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {records.map((r) => (
              <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                <td className="py-2.5 px-3 font-bold text-slate-900">
                  {r.shipToPartyDescription}
                </td>
                <td className="py-2.5 px-3 font-bold text-slate-700">{r.businessUnit}</td>
                <td className="py-2.5 px-3 font-bold text-slate-800">
                  <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-300">
                    Grade {r.storeGrade}
                  </span>
                </td>
                <td className="py-2.5 px-3 text-slate-600">{r.deliveryTime}</td>
                <td className="py-2.5 px-3 text-slate-600">{r.frequency}</td>
                <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                  {r.cap}
                </td>
                <td className="py-2.5 px-3 text-right font-extrabold text-slate-900">
                  {r.weeklyCap}
                </td>
                <td className="py-2.5 px-3 text-slate-700">
                  {r.driver} ({r.licensePlateNumber || 'N/A'})
                </td>
                <td className="py-2.5 px-3 text-[#2E5BFF]">{r.receiver}</td>
                <td className="py-2.5 px-3 font-mono text-slate-600">{r.omniActualLmd}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
