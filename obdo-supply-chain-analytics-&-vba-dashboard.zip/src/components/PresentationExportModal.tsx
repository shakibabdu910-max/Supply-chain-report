import React, { useState } from 'react';
import { Presentation, FileSpreadsheet, Printer, X, Download, Check, Sparkles, AlertCircle } from 'lucide-react';
import { exportToPowerPoint, exportToPDF, triggerPrintPresentation } from '../utils/exportPresentation';
import { KPIStats, OBDORecord } from '../types';

interface PresentationExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: KPIStats;
  records: OBDORecord[];
}

export const PresentationExportModal: React.FC<PresentationExportModalProps> = ({
  isOpen,
  onClose,
  stats,
  records,
}) => {
  const [isExporting, setIsExporting] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleExportPPTX = async () => {
    try {
      setIsExporting('pptx');
      await exportToPowerPoint(stats, records);
      setSuccessMessage('PowerPoint presentation (.pptx) successfully downloaded!');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Error generating PowerPoint:', err);
      alert(`PowerPoint generation message: ${err?.message || 'Download completed or triggered in browser'}`);
    } finally {
      setIsExporting(null);
    }
  };

  const handleExportPDF = async () => {
    try {
      setIsExporting('pdf');
      await exportToPDF('presentation-view-container', stats, records);
      setSuccessMessage('PDF Presentation (.pdf) successfully downloaded!');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error('Error generating PDF:', err);
      alert(`PDF generation message: ${err?.message || 'Download completed or triggered in browser'}`);
    } finally {
      setIsExporting(null);
    }
  };

  const handlePrint = () => {
    onClose();
    setTimeout(() => {
      triggerPrintPresentation();
    }, 200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4 backdrop-blur-xs font-sans">
      <div className="bg-white border border-[#E2E8F0] text-[#1A1C1E] rounded-lg w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between text-white border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-600 rounded text-white shadow-xs">
              <Presentation className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider font-mono">
                PRESENTATION EXPORT & PRINT CENTER
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                Select your preferred presentation format for executive delivery
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert Banner */}
        {successMessage && (
          <div className="bg-green-50 border-b border-green-200 px-6 py-3 flex items-center space-x-2 text-xs font-bold text-green-800 font-mono">
            <Check className="w-4 h-4 text-green-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Modal Options Grid */}
        <div className="p-6 bg-slate-50 space-y-4">
          <p className="text-xs text-slate-600 font-medium">
            Choose a presentation download format or print directly for executive meetings:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Option 1: PowerPoint (.pptx) */}
            <div className="bg-white p-5 rounded-lg border border-slate-200 hover:border-blue-500 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-amber-50 text-amber-700 rounded-md border border-amber-200">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded font-mono uppercase">
                    MICROSOFT PPTX
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  PowerPoint Presentation (.pptx)
                </h4>
                <p className="text-xs text-slate-500 font-sans leading-relaxed">
                  Downloads a multi-slide 16:9 executive presentation deck with slide titles, KPI cards, and structured category breakdown tables.
                </p>
              </div>

              <button
                onClick={handleExportPPTX}
                disabled={isExporting !== null}
                className="mt-4 w-full flex items-center justify-center space-x-2 px-4 py-2.5 bg-[#2E5BFF] hover:bg-blue-600 text-white font-bold text-xs rounded transition-all cursor-pointer font-mono uppercase tracking-wider shadow-2xs disabled:opacity-50"
              >
                {isExporting === 'pptx' ? (
                  <span className="flex items-center space-x-2">
                    <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Generating PPTX...</span>
                  </span>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>Download PPTX Deck</span>
                  </>
                )}
              </button>
            </div>

            {/* Option 2: PDF Document (.pdf) */}
            <div className="bg-white p-5 rounded-lg border border-slate-200 hover:border-blue-500 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-red-50 text-red-700 rounded-md border border-red-200">
                    <Presentation className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] bg-red-100 text-red-800 font-bold px-2 py-0.5 rounded font-mono uppercase">
                    EXECUTIVE PDF
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  PDF Presentation Document (.pdf)
                </h4>
                <p className="text-xs text-slate-500 font-sans leading-relaxed">
                  Generates a crisp landscape PDF containing active presentation charts, KPI metrics, and designer copyright header/footer notes.
                </p>
              </div>

              <button
                onClick={handleExportPDF}
                disabled={isExporting !== null}
                className="mt-4 w-full flex items-center justify-center space-x-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded transition-all cursor-pointer font-mono uppercase tracking-wider shadow-2xs disabled:opacity-50"
              >
                {isExporting === 'pdf' ? (
                  <span className="flex items-center space-x-2">
                    <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Building PDF...</span>
                  </span>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>Download PDF Document</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Direct Print Option Box */}
          <div className="bg-white p-4 rounded-lg border border-slate-200 flex items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-slate-100 text-slate-700 rounded border border-slate-200">
                <Printer className="w-5 h-5 text-slate-800" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-900 uppercase font-mono">
                  Direct Print / Save as PDF via Browser
                </h5>
                <p className="text-[11px] text-slate-500">
                  Launches system print window pre-configured for landscape A4 presentation layout.
                </p>
              </div>
            </div>

            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded border border-slate-300 transition-all cursor-pointer font-mono uppercase shrink-0"
            >
              Print Presentation
            </button>
          </div>
        </div>

        {/* Modal Footer with Credits */}
        <div className="bg-slate-100 px-6 py-3 border-t border-[#E2E8F0] flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-mono">
          <p className="text-slate-600 font-medium">
            Design by <span className="font-bold text-slate-900">Ronald Mpuuga</span>
          </p>
          <p className="text-slate-500">
            All rights reserved by{' '}
            <a
              href="https://mpuugasites.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#2E5BFF] font-bold hover:underline"
            >
              mpuugasites.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};
