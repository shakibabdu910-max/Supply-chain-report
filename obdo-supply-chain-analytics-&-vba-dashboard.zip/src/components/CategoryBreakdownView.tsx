import React from 'react';
import { OBDORecord, KPIStats } from '../types';
import { Layers, Shirt, Footprints, Briefcase, Dumbbell, Boxes } from 'lucide-react';

interface CategoryBreakdownViewProps {
  records: OBDORecord[];
  stats: KPIStats;
}

export const CategoryBreakdownView: React.FC<CategoryBreakdownViewProps> = ({
  records,
  stats,
}) => {
  const totalItems =
    stats.totalApparel +
    stats.totalFootwear +
    stats.totalAccessories +
    stats.totalEquipment;

  const categories = [
    {
      name: 'Apparel',
      qty: stats.totalApparel,
      icon: Shirt,
      color: 'bg-[#2E5BFF]',
      textColor: 'text-[#2E5BFF]',
      percent: totalItems > 0 ? (stats.totalApparel / totalItems) * 100 : 0,
    },
    {
      name: 'Footwear',
      qty: stats.totalFootwear,
      icon: Footprints,
      color: 'bg-purple-600',
      textColor: 'text-purple-600',
      percent: totalItems > 0 ? (stats.totalFootwear / totalItems) * 100 : 0,
    },
    {
      name: 'Accessories',
      qty: stats.totalAccessories,
      icon: Briefcase,
      color: 'bg-amber-600',
      textColor: 'text-amber-600',
      percent: totalItems > 0 ? (stats.totalAccessories / totalItems) * 100 : 0,
    },
    {
      name: 'Equipment',
      qty: stats.totalEquipment,
      icon: Dumbbell,
      color: 'bg-green-600',
      textColor: 'text-green-600',
      percent: totalItems > 0 ? (stats.totalEquipment / totalItems) * 100 : 0,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <div
              key={cat.name}
              className="bg-white border border-[#E2E8F0] rounded p-4 text-[#1A1C1E] shadow-2xs font-mono"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase text-slate-500">
                  {cat.name}
                </span>
                <div className={`p-1.5 rounded text-white ${cat.color}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline space-x-2">
                <span className="text-2xl font-bold text-slate-900">
                  {cat.qty.toLocaleString()}
                </span>
                <span className={`text-xs font-bold ${cat.textColor}`}>
                  ({cat.percent.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 h-1 rounded-full mt-3 overflow-hidden border border-slate-200">
                <div
                  className={`h-full ${cat.color}`}
                  style={{ width: `${cat.percent}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Category Matrix Table */}
      <div className="bg-white border border-[#E2E8F0] rounded p-5 text-[#1A1C1E] shadow-2xs overflow-x-auto">
        <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-2 font-mono">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
            <Boxes className="w-4 h-4 text-[#2E5BFF]" />
            DETAILED PRODUCT CATEGORY & PACKAGING MATRIX
          </h3>
          <span className="text-xs text-slate-500">By OBDO Order</span>
        </div>

        <table className="w-full text-left text-xs font-mono border-collapse data-table">
          <thead>
            <tr className="bg-slate-100 text-slate-700 border-b border-[#E2E8F0]">
              <th className="py-2.5 px-3 font-bold">OBDO ID</th>
              <th className="py-2.5 px-3 font-bold">Brand</th>
              <th className="py-2.5 px-3 font-bold">Ship-To Party</th>
              <th className="py-2.5 px-3 font-bold text-right">Apparel</th>
              <th className="py-2.5 px-3 font-bold text-right">Footwear</th>
              <th className="py-2.5 px-3 font-bold text-right">Accessories</th>
              <th className="py-2.5 px-3 font-bold text-right">Equipment</th>
              <th className="py-2.5 px-3 font-bold text-right">Total EWM QTY</th>
              <th className="py-2.5 px-3 font-bold text-right">Cartons</th>
              <th className="py-2.5 px-3 font-bold text-right">Pallets</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {records.map((r) => (
              <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                <td className="py-2.5 px-3 font-bold text-[#2E5BFF]">{r.obdo}</td>
                <td className="py-2.5 px-3 font-bold text-slate-800">{r.brand}</td>
                <td className="py-2.5 px-3 text-slate-700">{r.shipToPartyDescription}</td>
                <td className="py-2.5 px-3 text-right font-medium text-amber-600">
                  {r.apparel}
                </td>
                <td className="py-2.5 px-3 text-right font-medium text-purple-600">
                  {r.footwear}
                </td>
                <td className="py-2.5 px-3 text-right text-slate-600">{r.accessories}</td>
                <td className="py-2.5 px-3 text-right text-slate-600">{r.equipment}</td>
                <td className="py-2.5 px-3 text-right font-bold text-[#2E5BFF]">
                  {r.ewmObdoItemTotalQty}
                </td>
                <td className="py-2.5 px-3 text-right font-semibold text-slate-800">
                  {r.numberOfCartons}
                </td>
                <td className="py-2.5 px-3 text-right text-slate-600">
                  {r.numberOfPallets}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
