import React from 'react';
import { OBDORecord, KPIStats } from '../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Truck, Layers, Building2, Store, Calendar, CheckCircle2 } from 'lucide-react';

interface DashboardViewProps {
  records: OBDORecord[];
  stats: KPIStats;
}

const BRAND_COLORS: Record<string, string> = {
  NIKE: '#2E5BFF', // tech blue
  JRDN: '#F27D26', // orange accent
  ADIDAS: '#10B981', // green
  PUMA: '#8B5CF6', // purple
};

const GRADE_COLORS = ['#2E5BFF', '#3B82F6', '#60A5FA', '#93C5FD'];

export const DashboardView: React.FC<DashboardViewProps> = ({ records, stats }) => {
  // Aggregate Brand Data
  const brandDataMap = new Map<
    string,
    {
      brand: string;
      ewmQty: number;
      packedQty: number;
      apparel: number;
      footwear: number;
      accEq: number;
      cartons: number;
    }
  >();

  records.forEach((r) => {
    const b = r.brand || 'Other';
    const curr = brandDataMap.get(b) || {
      brand: b,
      ewmQty: 0,
      packedQty: 0,
      apparel: 0,
      footwear: 0,
      accEq: 0,
      cartons: 0,
    };
    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.packedQty += Number(r.packedQty) || 0;
    curr.apparel += Number(r.apparel) || 0;
    curr.footwear += Number(r.footwear) || 0;
    curr.accEq += (Number(r.accessories) || 0) + (Number(r.equipment) || 0);
    curr.cartons += Number(r.numberOfCartons) || 0;
    brandDataMap.set(b, curr);
  });

  const brandChartData = Array.from(brandDataMap.values());

  // Aggregate Business Unit Data
  const buDataMap = new Map<
    string,
    {
      bu: string;
      ewmQty: number;
      packedQty: number;
      orders: number;
      cartons: number;
    }
  >();

  records.forEach((r) => {
    const bu = r.businessUnit || 'Unassigned';
    const curr = buDataMap.get(bu) || {
      bu,
      ewmQty: 0,
      packedQty: 0,
      orders: 0,
      cartons: 0,
    };
    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.packedQty += Number(r.packedQty) || 0;
    curr.orders += 1;
    curr.cartons += Number(r.numberOfCartons) || 0;
    buDataMap.set(bu, curr);
  });

  const buChartData = Array.from(buDataMap.values());

  // Aggregate OMNI Actual LMD Data
  const lmdDataMap = new Map<
    string,
    {
      status: string;
      ewmQty: number;
      orders: number;
      cartons: number;
    }
  >();

  records.forEach((r) => {
    const lmd = (r.omniActualLmd || '').trim() || '#N/A';
    const curr = lmdDataMap.get(lmd) || {
      status: lmd,
      ewmQty: 0,
      orders: 0,
      cartons: 0,
    };
    curr.ewmQty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.orders += 1;
    curr.cartons += Number(r.numberOfCartons) || 0;
    lmdDataMap.set(lmd, curr);
  });

  const lmdChartData = Array.from(lmdDataMap.values()).sort((a, b) => b.ewmQty - a.ewmQty);

  // Aggregate Store Grade Distribution
  const gradeDataMap = new Map<string, number>();
  records.forEach((r) => {
    const g = r.storeGrade ? `Grade ${r.storeGrade}` : 'Unassigned';
    gradeDataMap.set(
      g,
      (gradeDataMap.get(g) || 0) + (Number(r.ewmObdoItemTotalQty) || 0)
    );
  });

  const gradeChartData = Array.from(gradeDataMap.entries()).map(
    ([name, value]) => ({
      name,
      value,
    })
  );

  // Aggregate Top Ship-To Party Destinations
  const shipToMap = new Map<
    string,
    { name: string; qty: number; cartons: number; grade: string }
  >();
  records.forEach((r) => {
    const desc = r.shipToPartyDescription || r.shipTo || 'Unknown';
    const curr = shipToMap.get(desc) || {
      name: desc,
      qty: 0,
      cartons: 0,
      grade: r.storeGrade || 'N/A',
    };
    curr.qty += Number(r.ewmObdoItemTotalQty) || 0;
    curr.cartons += Number(r.numberOfCartons) || 0;
    shipToMap.set(desc, curr);
  });

  const topShipToData = Array.from(shipToMap.values())
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Visual Section: 2 Main Visual Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Brand Quantity & Category Breakdown Chart */}
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E]">
          <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-3">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-[#2E5BFF]" />
              <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                EWM OBDO ITEM QTY & CATEGORY BREAKDOWN BY BRAND
              </h3>
            </div>
            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono font-bold">
              REAL-TIME
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={brandChartData}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="brand" stroke="#64748B" fontSize={11} tickLine={false} fontFamily="monospace" />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1A1C1E',
                    borderColor: '#E2E8F0',
                    borderRadius: '4px',
                    color: '#fff',
                    fontSize: '11px',
                    fontFamily: 'monospace',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', color: '#64748B', fontFamily: 'monospace' }} />
                <Bar dataKey="ewmQty" name="Total EWM QTY" fill="#2E5BFF" radius={[2, 2, 0, 0]} />
                <Bar dataKey="packedQty" name="Packed QTY" fill="#10B981" radius={[2, 2, 0, 0]} />
                <Bar dataKey="apparel" name="Apparel" fill="#F27D26" radius={[2, 2, 0, 0]} />
                <Bar dataKey="footwear" name="Footwear" fill="#8B5CF6" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Store Grade Distribution Pie/Donut Chart */}
        <div className="bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-3">
              <div className="flex items-center space-x-2">
                <Store className="w-4 h-4 text-[#2E5BFF]" />
                <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                  VOLUME BY STORE GRADE
                </h3>
              </div>
            </div>

            <div className="h-56 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={gradeChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {gradeChartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={GRADE_COLORS[index % GRADE_COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1A1C1E',
                      borderColor: '#E2E8F0',
                      borderRadius: '4px',
                      color: '#fff',
                      fontSize: '11px',
                      fontFamily: 'monospace',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center font-mono">
                <span className="text-xl font-bold text-[#1A1C1E]">{stats.totalEwmQty}</span>
                <span className="text-[10px] text-slate-500 font-bold uppercase">TOTAL QTY</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-[#E2E8F0] font-mono">
            {gradeChartData.map((item, idx) => (
              <div key={item.name} className="flex items-center space-x-2 text-xs">
                <span
                  className="w-2.5 h-2.5 rounded-xs shrink-0"
                  style={{ backgroundColor: GRADE_COLORS[idx % GRADE_COLORS.length] }}
                ></span>
                <span className="text-slate-500 truncate">{item.name}:</span>
                <span className="text-slate-900 font-bold">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Dedicated Section: Business Unit & OMNI Actual LMD Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Business Unit Distribution Chart */}
        <div className="bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E]">
          <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-3">
            <div className="flex items-center space-x-2">
              <Building2 className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                BUSINESS UNIT VOLUME & FULFILLMENT BREAKDOWN
              </h3>
            </div>
            <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded font-mono font-bold">
              {stats.totalBusinessUnits} Active BUs
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={buChartData}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="bu" stroke="#64748B" fontSize={11} tickLine={false} fontFamily="monospace" />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1A1C1E',
                    borderColor: '#E2E8F0',
                    borderRadius: '4px',
                    color: '#fff',
                    fontSize: '11px',
                    fontFamily: 'monospace',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', color: '#64748B', fontFamily: 'monospace' }} />
                <Bar dataKey="ewmQty" name="EWM QTY" fill="#6366F1" radius={[2, 2, 0, 0]} />
                <Bar dataKey="packedQty" name="Packed QTY" fill="#10B981" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* BU Summary Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-[#E2E8F0] font-mono text-xs">
            {buChartData.slice(0, 4).map((b) => (
              <div key={b.bu} className="bg-slate-50 p-2 rounded border border-slate-200">
                <div className="text-[10px] text-slate-500 font-bold uppercase truncate">{b.bu}</div>
                <div className="text-sm font-bold text-slate-900">{b.ewmQty} QTY</div>
                <div className="text-[10px] text-slate-500">{b.orders} Orders</div>
              </div>
            ))}
          </div>
        </div>

        {/* OMNI Actual LMD Logistics Tracker */}
        <div className="bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-[#E2E8F0] pb-3">
              <div className="flex items-center space-x-2">
                <Truck className="w-4 h-4 text-[#2E5BFF]" />
                <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                  OMNI ACTUAL LMD LOGISTICS STATUS
                </h3>
              </div>
              <span className="text-[10px] bg-blue-50 text-[#2E5BFF] border border-blue-200 px-2 py-0.5 rounded font-mono font-bold">
                {stats.activeOmniLmdCount} Scheduled
              </span>
            </div>

            <div className="space-y-2.5 font-mono">
              {lmdChartData.map((item) => (
                <div
                  key={item.status}
                  className="bg-slate-50 p-2.5 rounded border border-slate-200 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.status === '#N/A'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-blue-100 text-[#2E5BFF] border border-blue-300'
                      }`}
                    >
                      {item.status}
                    </span>
                    <span className="text-xs text-slate-700 font-medium">
                      {item.status === '#N/A' ? 'Pending Allocation' : 'LMD Schedule Confirmed'}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold text-slate-900 block">
                      {item.ewmQty} Units
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {item.orders} Orders • {item.cartons} Cartons
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50/60 p-3 rounded border border-blue-200 mt-4 text-xs font-mono text-slate-700 flex items-center justify-between">
            <span>OMNI LMD Schedule Alignment Rate:</span>
            <span className="font-bold text-[#2E5BFF] text-sm">
              {stats.totalOrders > 0
                ? ((stats.activeOmniLmdCount / stats.totalOrders) * 100).toFixed(1)
                : 0}
              %
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Section: Top Ship-To Destinations & Delivery Priority Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Destination Ship-To Summary */}
        <div className="bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E]">
          <div className="flex items-center justify-between mb-3 border-b border-[#E2E8F0] pb-2">
            <div className="flex items-center space-x-2">
              <Truck className="w-4 h-4 text-[#2E5BFF]" />
              <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                TOP SHIP-TO STORE DESTINATIONS
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-mono">By Volume</span>
          </div>

          <div className="space-y-2.5">
            {topShipToData.map((s, idx) => (
              <div
                key={s.name}
                className="sidebar-stat bg-slate-50 p-2.5 rounded border border-slate-200 flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <span className="w-5 h-5 rounded bg-slate-200 text-slate-800 font-mono flex items-center justify-center font-bold text-xs">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="text-xs font-bold text-slate-900 leading-tight">
                      {s.name}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      Grade {s.grade} • {s.cartons} Cartons
                    </div>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <div className="text-xs font-bold text-[#2E5BFF]">
                    {s.qty} QTY
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {((s.qty / (stats.totalEwmQty || 1)) * 100).toFixed(1)}% total
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Goods Issue & Delivery Fulfillment Status */}
        <div className="bg-white border border-[#E2E8F0] rounded p-5 shadow-2xs text-[#1A1C1E] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-[#E2E8F0] pb-2">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <h3 className="text-xs font-bold text-slate-800 tracking-wider uppercase font-mono">
                  FULFILLMENT & WEEKLY CAP CAPACITY
                </h3>
              </div>
            </div>

            <div className="space-y-4 my-2 font-mono">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Packing & Picking Completion</span>
                  <span className="text-green-600 font-bold">{stats.packingCompletionRate.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
                  <div
                    className="bg-green-600 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(stats.packingCompletionRate, 100)}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Weekly CAP Load Utilization ({stats.totalEwmQty} / {stats.totalWeeklyCap})</span>
                  <span className="text-[#2E5BFF] font-bold">{stats.capUtilizationRate.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
                  <div
                    className="bg-[#2E5BFF] h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(stats.capUtilizationRate, 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded border border-slate-200 mt-4 text-xs font-mono text-slate-700 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-[#2E5BFF]" />
              <span>Daily CAP Capacity:</span>
            </div>
            <span className="font-bold text-slate-900 text-sm">
              {stats.totalDailyCap.toLocaleString()} Units/Day
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
