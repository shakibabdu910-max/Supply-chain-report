import React from 'react';
import {
  FileCode,
  Upload,
  Download,
  RotateCw,
  BarChart3,
  Presentation,
  Trash2,
} from 'lucide-react';

interface HeaderProps {
  onOpenImport: () => void;
  onOpenVBA: () => void;
  onExportExcel: () => void;
  onOpenPresentationExport: () => void;
  onRefreshData: () => void;
  onClearData: () => void;
  onRestoreSampleData: () => void;
  totalRecords: number;
  isPresentationMode: boolean;
  setIsPresentationMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenImport,
  onOpenVBA,
  onExportExcel,
  onOpenPresentationExport,
  onRefreshData,
  onClearData,
  onRestoreSampleData,
  totalRecords,
  isPresentationMode,
  setIsPresentationMode,
}) => {
  return (
    <header className="bg-white text-[#1A1C1E] border-b border-[#E2E8F0] sticky top-0 z-30 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Title */}
        <div className="flex items-center space-x-3">
          <div className="bg-[#1A1C1E] p-2 rounded text-white shadow-xs">
            <BarChart3 className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-bold tracking-tight text-[#1A1C1E] font-sans uppercase">
                OUTBOUND LOGISTICS CONTROL TOWER
              </h1>
              <span className="bg-blue-50 text-[#2E5BFF] text-[10px] px-2 py-0.5 rounded font-bold font-mono border border-blue-200">
                REAL-TIME
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono uppercase">
              SAP EWM | OBDO Daily Executive Summary | {totalRecords} Records
            </p>
          </div>
        </div>

        {/* System Status & Action Controls */}
        <div className="flex items-center flex-wrap gap-2.5">
          <div className="hidden sm:block text-right pr-2 border-r border-slate-200">
            <p className="text-[10px] text-slate-400 font-mono uppercase">System Status</p>
            <p className="text-xs font-bold text-green-600 font-mono flex items-center justify-end gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              REAL-TIME SYNC ACTIVE
            </p>
          </div>

          {/* Daily Data Update Button */}
          <button
            onClick={onOpenImport}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1A1C1E] hover:bg-slate-800 text-white text-xs font-bold rounded shadow-2xs transition-all cursor-pointer font-mono uppercase tracking-wider"
            title="Paste or upload daily updated OBDO data"
          >
            <Upload className="w-3.5 h-3.5 text-blue-400" />
            <span>Update / Import Data</span>
          </button>

          {/* Clear / Delete Current Dataset */}
          {totalRecords > 0 ? (
            <button
              onClick={onClearData}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded border border-red-200 transition-all cursor-pointer font-mono uppercase tracking-wider"
              title="Delete all available data to upload a new dataset"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-600" />
              <span>Delete Data</span>
            </button>
          ) : (
            <button
              onClick={onRestoreSampleData}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-green-50 hover:bg-green-100 text-green-800 text-xs font-bold rounded border border-green-200 transition-all cursor-pointer font-mono uppercase tracking-wider"
              title="Restore sample demo dataset"
            >
              <RotateCw className="w-3.5 h-3.5 text-green-600" />
              <span>Restore Sample Data</span>
            </button>
          )}

          {/* Refresh Data */}
          <button
            onClick={onRefreshData}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded border border-slate-300 transition-all cursor-pointer"
            title="Refresh Real-time Metrics"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* VBA Code Generator */}
          <button
            onClick={onOpenVBA}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#2E5BFF] hover:bg-blue-600 text-white text-xs font-bold rounded shadow-2xs transition-all cursor-pointer font-mono uppercase tracking-wider"
            title="Generate Excel VBA Script with collision protection"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>VBA Macro</span>
          </button>

          {/* Export Excel */}
          <button
            onClick={onExportExcel}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded shadow-2xs transition-all cursor-pointer font-mono uppercase tracking-wider"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>

          {/* Export PPTX / PDF Presentation */}
          <button
            onClick={onOpenPresentationExport}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded shadow-2xs transition-all cursor-pointer font-mono uppercase tracking-wider"
            title="Download Presentation as PowerPoint (.pptx) or PDF (.pdf)"
          >
            <Presentation className="w-3.5 h-3.5 text-amber-300" />
            <span>PPTX / PDF Print</span>
          </button>

          {/* Presentation Mode Toggle */}
          <button
            onClick={() => setIsPresentationMode(!isPresentationMode)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold rounded border font-mono transition-all cursor-pointer uppercase ${
              isPresentationMode
                ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <Presentation className="w-3.5 h-3.5 text-[#2E5BFF]" />
            <span>{isPresentationMode ? 'Exit' : 'Presentation'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

