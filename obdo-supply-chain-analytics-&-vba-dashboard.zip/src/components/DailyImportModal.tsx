import React, { useState } from 'react';
import { OBDORecord } from '../types';
import { Upload, X, Check, FileCheck2, AlertCircle, Trash2, RefreshCw } from 'lucide-react';

interface DailyImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdateRecords: (newRecords: OBDORecord[], shouldReplace: boolean) => void;
  totalRecords: number;
  onClearAllData: () => void;
}

export const DailyImportModal: React.FC<DailyImportModalProps> = ({
  isOpen,
  onClose,
  onUpdateRecords,
  totalRecords,
  onClearAllData,
}) => {
  const [pastedText, setPastedText] = useState('');
  const [replaceExisting, setReplaceExisting] = useState(true);
  const [parsedCount, setParsedCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleParseAndImport = () => {
    setError(null);
    if (!pastedText.trim()) {
      setError('Please paste raw TSV, CSV or Excel data first.');
      return;
    }

    try {
      const lines = pastedText.trim().split(/\r?\n/);
      if (lines.length < 2) {
        setError('At least header row and 1 data row required.');
        return;
      }

      // Detect delimiter (tab or comma)
      const firstLine = lines[0];
      const delimiter = firstLine.includes('\t') ? '\t' : ',';

      const headers = firstLine.split(delimiter).map((h) => h.trim().toLowerCase());

      const newRecords: OBDORecord[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = line.split(delimiter).map((c) => c.trim().replace(/^"|"$/g, ''));

        // Helper to get col value by matching header keyword
        const getCol = (keywords: string[]): string => {
          for (let k of keywords) {
            const idx = headers.findIndex((h) => h.includes(k.toLowerCase()));
            if (idx !== -1 && cols[idx] !== undefined) return cols[idx];
          }
          return '';
        };

        const record: OBDORecord = {
          id: `import-${i}-${Date.now()}`,
          obdo: getCol(['document (obdo)', 'obdo', 'document']) || cols[0] || `10100${i}`,
          erpDocument: getCol(['erp document', 'erp']) || cols[1] || '',
          brand: getCol(['brand']) || cols[2] || 'NIKE',
          businessScenario: getCol(['business scenario', 'scenario']) || cols[3] || 'RETUAE',
          route: getCol(['route']) || cols[4] || '',
          shipTo: getCol(['ship-to', 'shipto']) || cols[5] || '',
          shipToPartyDescription: getCol(['ship-to party description', 'ship-to party']) || cols[6] || 'Store Destination',
          toStorageLocation: getCol(['to storage location']) || cols[7] || 'SL01',
          stgeLocDescription: getCol(['stge loc. description']) || cols[8] || 'Sellable Loc',
          createdOn: getCol(['created on']) || cols[9] || '18/06/2026',
          createdAt: getCol(['created at']) || cols[10] || '12:00:00',
          whseProcType: getCol(['whse proc. type', 'whse proc']) || cols[11] || '2012',
          numberOfItems: Number(getCol(['number of items'])) || Number(cols[12]) || 1,
          sapObdItemTotalQty: Number(getCol(['sap obd item total qty'])) || Number(cols[13]) || 10,
          ewmObdoItemTotalQty: Number(getCol(['ewm obdo item total  qty', 'ewm obdo item total qty', 'ewm'])) || Number(cols[14]) || 10,
          packedQty: Number(getCol(['packed qty'])) || Number(cols[15]) || 10,
          dpTotalQty: Number(getCol(['dp total qty'])) || Number(cols[16]) || 0,
          dnTotalQty: Number(getCol(['dn total qty'])) || Number(cols[17]) || 10,
          apparel: Number(getCol(['apparel'])) || Number(cols[18]) || 0,
          footwear: Number(getCol(['footwear'])) || Number(cols[19]) || 0,
          accessories: Number(getCol(['accessories'])) || Number(cols[20]) || 0,
          equipment: Number(getCol(['equipment'])) || Number(cols[21]) || 0,
          numberOfCartons: Number(getCol(['number of cartons', 'cartons'])) || Number(cols[22]) || 1,
          numberOfPallets: Number(getCol(['number of pallets', 'pallets'])) || Number(cols[23]) || 1,
          pickingStatusPlan: getCol(['picking status (plan)']) || 'Completed',
          pickingStatusAct: getCol(['picking status']) || 'Completed',
          packingStatus: getCol(['packing status']) || 'Completed',
          actualPickingDate: getCol(['actual picking date']) || '',
          packingDate: getCol(['packing date']) || '',
          packingTime: getCol(['packing time']) || '',
          plannedRouteDepartureDate: getCol(['planned route departure date']) || '',
          ownerOfStock: getCol(['owner of stock']) || '1D00',
          storageLocation: getCol(['storage location']) || 'SL02',
          warehouseActivityStatus: getCol(['warehouse activity status']) || 'Completed',
          transportationUnit: getCol(['transportation unit']) || '',
          vehicle: getCol(['vehicle']) || '',
          loadingStatus: getCol(['loading status']) || 'Completed',
          loadingDateAct: getCol(['loading date (act.)']) || '',
          goodsIssueStatus: getCol(['goods issue status']) || 'Completed',
          goodsIssueStatusDate: getCol(['goods issue status date']) || '11/08/2026',
          licensePlateNumber: getCol(['license plate number']) || '',
          driver: getCol(['driver']) || 'DEVRAJ',
          documentType: getCol(['document type']) || 'ZFTH',
          description: getCol(['description']) || 'Outbound Delivery',
          purchaseOrder: getCol(['purchase order']) || '',
          userComments: getCol(['user comments']) || '',
          wave: getCol(['wave']) || '',
          pickingCompletionTime: getCol(['picking completion time']) || '',
          deliveryPriority: Number(getCol(['delivery priority'])) || 0,
          businessUnit: getCol(['business unit']) || 'SSS-RET',
          omniActualLmd: getCol(['omni actual lmd']) || '#N/A',
          storeGrade: getCol(['store grade']) || 'D',
          releaseDate: getCol(['release date']) || '',
          releaseTime: getCol(['release time']) || '',
          mdcRemarks: getCol(['mdc remarks']) || '',
          deliveryOnDate: getCol(['delivery on date']) || '',
          receiver: getCol(['receiver']) || 'RT-10/11',
          sfccNumber: getCol(['sfcc number']) || '',
          cap: Number(getCol(['cap'])) || 500,
          deliveryTime: getCol(['delivery time']) || 'MORNING',
          frequency: getCol(['frequency']) || '3 Times in a Week',
          weeklyCap: Number(getCol(['weekly cap'])) || 1500,
        };

        newRecords.push(record);
      }

      setParsedCount(newRecords.length);
      onUpdateRecords(newRecords, replaceExisting);
      setTimeout(() => {
        onClose();
        setPastedText('');
        setParsedCount(null);
      }, 1000);
    } catch (err: any) {
      setError('Error parsing data. Please check column format and try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4 backdrop-blur-xs font-mono">
      <div className="bg-white border border-[#E2E8F0] text-[#1A1C1E] rounded w-full max-w-3xl overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-slate-100 px-6 py-4 flex items-center justify-between border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Upload className="w-4 h-4 text-[#2E5BFF]" />
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              DAILY OBDO DATA UPDATE & IMPORT
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-200 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50 p-3 rounded border border-slate-200 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-700">Import Mode:</span>
              <label className="inline-flex items-center space-x-1.5 cursor-pointer">
                <input
                  type="radio"
                  name="importMode"
                  checked={replaceExisting}
                  onChange={() => setReplaceExisting(true)}
                  className="text-[#2E5BFF] focus:ring-[#2E5BFF]"
                />
                <span className="text-slate-900 font-bold">Wipe & Replace Current ({totalRecords}) Data</span>
              </label>
              <label className="inline-flex items-center space-x-1.5 cursor-pointer ml-3">
                <input
                  type="radio"
                  name="importMode"
                  checked={!replaceExisting}
                  onChange={() => setReplaceExisting(false)}
                  className="text-[#2E5BFF] focus:ring-[#2E5BFF]"
                />
                <span className="text-slate-700">Append to Existing</span>
              </label>
            </div>

            {totalRecords > 0 && (
              <button
                onClick={() => {
                  if (window.confirm('Are you sure you want to delete all current records?')) {
                    onClearAllData();
                  }
                }}
                className="flex items-center space-x-1 text-red-600 hover:text-red-700 font-bold cursor-pointer text-[11px]"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Dataset Now</span>
              </button>
            )}
          </div>

          <p className="text-xs text-slate-600">
            Copy and paste your updated daily OBDO raw dataset directly from Excel or CSV (tab-separated or comma-separated). The dashboard will re-calculate all visual KPIs and pivot tables in real-time.
          </p>

          <textarea
            rows={8}
            placeholder="Paste raw Excel data here (Include headers: Document (OBDO), Brand, Ship-To Party Description, EWM OBDO Item Total QTY, Business Unit, OMNI Actual LMD, etc.)..."
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            className="w-full bg-slate-50 text-xs font-mono text-slate-900 p-3 rounded border border-slate-300 focus:outline-none focus:border-[#2E5BFF] focus:bg-white placeholder:text-slate-400"
          ></textarea>

          {error && (
            <div className="bg-red-50 border border-red-200 p-3 rounded flex items-center space-x-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {parsedCount !== null && (
            <div className="bg-green-50 border border-green-200 p-3 rounded flex items-center space-x-2 text-xs text-green-800">
              <FileCheck2 className="w-4 h-4 shrink-0 text-green-600" />
              <span>Successfully parsed {parsedCount} OBDO records! Updating dashboard...</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-100 px-6 py-4 flex items-center justify-between border-t border-[#E2E8F0]">
          <span className="text-[11px] text-slate-500 font-mono">
            Auto-Detects Delimiters & Column Names
          </span>
          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleParseAndImport}
              className="flex items-center space-x-1.5 px-4 py-2 bg-[#2E5BFF] hover:bg-blue-600 text-white text-xs font-bold rounded shadow-2xs border border-blue-500 cursor-pointer transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>{replaceExisting ? 'Replace Data & Update Dashboard' : 'Append Data & Update'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

