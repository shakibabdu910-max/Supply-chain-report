import React from 'react';
import { FilterState } from '../types';
import { Filter, Search, RefreshCcw, Tag, Building, Store, Truck, Calendar, X, Check } from 'lucide-react';

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  availableBrands: string[];
  availableScenarios: string[];
  availableBUs: string[];
  availableGrades: string[];
  availableProcTypes: string[];
  availableOmniLmds: string[];
  availableGIDates?: string[];
  onResetFilters: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  setFilters,
  availableBrands,
  availableScenarios,
  availableBUs,
  availableGrades,
  availableProcTypes,
  availableOmniLmds,
  availableGIDates = [],
  onResetFilters,
}) => {
  return (
    <div className="bg-white border border-[#E2E8F0] rounded p-4 mb-6 shadow-2xs text-[#1A1C1E]">
      {/* Top Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3 border-b border-[#E2E8F0] pb-2">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-[#2E5BFF]" />
          <span className="text-xs font-bold uppercase font-mono tracking-wider text-slate-700">
            CONTROL TOWER INTERACTIVE SLICERS
          </span>
        </div>

        <div className="flex items-center space-x-3">
          {filters.goodsIssueStatusDate && (
            <div className="flex items-center space-x-1.5 bg-blue-50 border border-blue-200 text-[#2E5BFF] px-2.5 py-1 rounded text-xs font-mono font-bold animate-pulse">
              <Calendar className="w-3.5 h-3.5" />
              <span>Goods Issue Date: {filters.goodsIssueStatusDate}</span>
              <button
                onClick={() => setFilters((prev) => ({ ...prev, goodsIssueStatusDate: '' }))}
                className="hover:text-red-600 ml-1 cursor-pointer"
                title="Clear Date Filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <button
            onClick={onResetFilters}
            className="text-xs text-slate-500 hover:text-[#2E5BFF] font-mono flex items-center space-x-1 underline cursor-pointer"
          >
            <RefreshCcw className="w-3 h-3" />
            <span>Reset All Slicers</span>
          </button>
        </div>
      </div>

      {/* Primary Slicer Controls Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-8 gap-3 font-mono">
        {/* Goods Issue Status Date Calendar Slicer */}
        <div className="lg:col-span-2 bg-gradient-to-r from-blue-50/80 to-indigo-50/80 border border-blue-200 rounded p-2">
          <label className="text-[10px] font-bold text-[#2E5BFF] uppercase flex items-center gap-1 mb-1">
            <Calendar className="w-3.5 h-3.5 text-[#2E5BFF]" /> GOODS ISSUE STATUS DATE
          </label>
          <div className="flex items-center gap-2">
            <select
              value={filters.goodsIssueStatusDate}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, goodsIssueStatusDate: e.target.value }))
              }
              className="w-full bg-white text-xs text-slate-900 font-bold px-2 py-1.5 rounded border border-blue-300 focus:outline-none focus:border-[#2E5BFF]"
            >
              <option value="">All Goods Issue Dates</option>
              {availableGIDates.map((dateStr) => (
                <option key={dateStr} value={dateStr}>
                  {dateStr}
                </option>
              ))}
            </select>

            <input
              type="date"
              title="Pick Date from Calendar"
              value={filters.goodsIssueStatusDate.includes('/') ? '' : filters.goodsIssueStatusDate}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, goodsIssueStatusDate: e.target.value }))
              }
              className="bg-white text-xs text-slate-800 px-1.5 py-1 rounded border border-blue-300 focus:outline-none focus:border-[#2E5BFF] cursor-pointer"
            />
          </div>
        </div>

        {/* Search Input */}
        <div className="lg:col-span-2">
          <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
            Search OBDO / ERP / BU / Customer
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="1010035878, SSS-RET, 11/08/2026..."
              value={filters.searchQuery}
              onChange={(e) =>
                setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))
              }
              className="w-full bg-slate-50 text-xs text-slate-900 pl-8 pr-3 py-1.5 rounded border border-slate-300 focus:outline-none focus:border-[#2E5BFF] focus:bg-white"
            />
          </div>
        </div>

        {/* Brand Slicer */}
        <div>
          <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1 mb-1">
            <Tag className="w-3 h-3 text-[#2E5BFF]" /> Brand
          </label>
          <select
            value={filters.brand}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, brand: e.target.value }))
            }
            className="w-full bg-slate-50 text-xs text-slate-900 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:border-[#2E5BFF] focus:bg-white"
          >
            <option value="">All Brands</option>
            {availableBrands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        </div>

        {/* Business Scenario Slicer */}
        <div>
          <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1 mb-1">
            <Building className="w-3 h-3 text-[#2E5BFF]" /> Scenario
          </label>
          <select
            value={filters.businessScenario}
            onChange={(e) =>
              setFilters((prev) => ({
                ...prev,
                businessScenario: e.target.value,
              }))
            }
            className="w-full bg-slate-50 text-xs text-slate-900 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:border-[#2E5BFF] focus:bg-white"
          >
            <option value="">All Scenarios</option>
            {availableScenarios.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Business Unit Slicer */}
        <div>
          <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1 mb-1">
            <Store className="w-3 h-3 text-[#2E5BFF]" /> Business Unit
          </label>
          <select
            value={filters.businessUnit}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, businessUnit: e.target.value }))
            }
            className="w-full bg-slate-50 text-xs text-slate-900 px-2 py-1.5 rounded border border-slate-300 focus:outline-none focus:border-[#2E5BFF] focus:bg-white font-bold"
          >
            <option value="">All BUs</option>
            {availableBUs.map((bu) => (
              <option key={bu} value={bu}>
                {bu}
              </option>
            ))}
          </select>
        </div>

        {/* OMNI Actual LMD Slicer */}
        <div>
          <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1 mb-1 text-[#2E5BFF]">
            <Truck className="w-3 h-3" /> OMNI LMD
          </label>
          <select
            value={filters.omniActualLmd}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, omniActualLmd: e.target.value }))
            }
            className="w-full bg-blue-50/50 text-xs text-[#2E5BFF] font-bold px-2 py-1.5 rounded border border-blue-200 focus:outline-none focus:border-[#2E5BFF] focus:bg-white"
          >
            <option value="">All OMNI LMDs</option>
            {availableOmniLmds.map((lmd) => (
              <option key={lmd} value={lmd}>
                {lmd}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
