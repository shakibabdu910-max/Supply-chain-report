import React, { useState, useMemo } from 'react';
import { OBDORecord, FilterState } from './types';
import { INITIAL_OBDO_DATA } from './data/sampleData';
import { calculateKPIs, filterRecords } from './utils/analytics';
import { Header } from './components/Header';
import { SidebarNav, NavTab } from './components/SidebarNav';
import { KPICards } from './components/KPICards';
import { FilterBar } from './components/FilterBar';
import { DashboardView } from './components/DashboardView';
import { PivotView } from './components/PivotView';
import { CategoryBreakdownView } from './components/CategoryBreakdownView';
import { StoreScheduleView } from './components/StoreScheduleView';
import { DataTable } from './components/DataTable';
import { DailyImportModal } from './components/DailyImportModal';
import { VBAScriptModal } from './components/VBAScriptModal';
import { PresentationExportModal } from './components/PresentationExportModal';
import { exportToPowerPoint, exportToPDF, triggerPrintPresentation } from './utils/exportPresentation';
import { Upload, RotateCw, Trash2, AlertCircle, Printer, Presentation, FileSpreadsheet, Download, Calendar } from 'lucide-react';
import * as XLSX from 'xlsx';

export default function App() {
  const [records, setRecords] = useState<OBDORecord[]>(INITIAL_OBDO_DATA);
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isPresentationMode, setIsPresentationMode] = useState(false);

  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isVBAOpen, setIsVBAOpen] = useState(false);
  const [isPresentationExportOpen, setIsPresentationExportOpen] = useState(false);

  const [filters, setFilters] = useState<FilterState>({
    brand: '',
    businessScenario: '',
    businessUnit: '',
    omniActualLmd: '',
    storeGrade: '',
    whseProcType: '',
    goodsIssueStatus: '',
    goodsIssueStatusDate: '',
    shipToParty: '',
    searchQuery: '',
    dateRangeStart: '',
    dateRangeEnd: '',
  });

  // Unique Slicer Values
  const availableBrands = useMemo(
    () => Array.from(new Set(records.map((r) => r.brand))).filter(Boolean),
    [records]
  );
  const availableScenarios = useMemo(
    () => Array.from(new Set(records.map((r) => r.businessScenario))).filter(Boolean),
    [records]
  );
  const availableBUs = useMemo(
    () => Array.from(new Set(records.map((r) => r.businessUnit))).filter(Boolean),
    [records]
  );
  const availableGrades = useMemo(
    () => Array.from(new Set(records.map((r) => r.storeGrade))).filter(Boolean),
    [records]
  );
  const availableProcTypes = useMemo(
    () => Array.from(new Set(records.map((r) => r.whseProcType))).filter(Boolean),
    [records]
  );
  const availableOmniLmds = useMemo(
    () => Array.from(new Set(records.map((r) => r.omniActualLmd))).filter(Boolean),
    [records]
  );
  const availableGIDates = useMemo(
    () => Array.from(new Set(records.map((r) => r.goodsIssueStatusDate))).filter(Boolean).sort(),
    [records]
  );

  // Filtered Records & Calculated KPI Metrics
  const filteredRecords = useMemo(
    () => filterRecords(records, filters),
    [records, filters]
  );

  const stats = useMemo(
    () => calculateKPIs(filteredRecords),
    [filteredRecords]
  );

  const handleResetFilters = () => {
    setFilters({
      brand: '',
      businessScenario: '',
      businessUnit: '',
      omniActualLmd: '',
      storeGrade: '',
      whseProcType: '',
      goodsIssueStatus: '',
      goodsIssueStatusDate: '',
      shipToParty: '',
      searchQuery: '',
      dateRangeStart: '',
      dateRangeEnd: '',
    });
  };

  const handleClearData = () => {
    if (window.confirm(`Are you sure you want to delete all ${records.length} records in the system? You can upload a new dataset or restore sample data.`)) {
      setRecords([]);
      handleResetFilters();
    }
  };

  const handleRestoreSampleData = () => {
    setRecords(INITIAL_OBDO_DATA);
    handleResetFilters();
  };

  const handleUpdateRecords = (newRecords: OBDORecord[], shouldReplace: boolean) => {
    if (shouldReplace) {
      setRecords(newRecords);
    } else {
      setRecords((prev) => [...prev, ...newRecords]);
    }
  };

  const handleExportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(filteredRecords);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'OBDO_Data');
    XLSX.writeFile(wb, `OBDO_Logistics_Export_${Date.now()}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] text-[#1A1C1E] flex flex-col font-sans antialiased">
      {/* Header */}
      {!isPresentationMode && (
        <Header
          onOpenImport={() => setIsImportOpen(true)}
          onOpenVBA={() => setIsVBAOpen(true)}
          onExportExcel={handleExportExcel}
          onOpenPresentationExport={() => setIsPresentationExportOpen(true)}
          onRefreshData={() => setRecords([...records])}
          onClearData={handleClearData}
          onRestoreSampleData={handleRestoreSampleData}
          totalRecords={records.length}
          isPresentationMode={isPresentationMode}
          setIsPresentationMode={setIsPresentationMode}
        />
      )}

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        {!isPresentationMode && (
          <SidebarNav
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isCollapsed={isSidebarCollapsed}
            setIsCollapsed={setIsSidebarCollapsed}
          />
        )}

        {/* Content View Container */}
        <main id="presentation-view-container" className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#F0F2F5]">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Empty Dataset Notification Banner */}
            {records.length === 0 && (
              <div className="bg-amber-50 border border-amber-300 p-5 rounded font-mono shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <AlertCircle className="w-6 h-6 text-amber-600 shrink-0" />
                  <div>
                    <h4 className="text-sm font-bold text-amber-900 uppercase">
                      CURRENT DATASET IS EMPTY
                    </h4>
                    <p className="text-xs text-amber-800">
                      All OBDO records have been deleted. Paste your daily updated dataset from Excel/CSV or restore sample demo data to populate analytics.
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  <button
                    onClick={() => setIsImportOpen(true)}
                    className="flex items-center space-x-1.5 px-3 py-2 bg-[#2E5BFF] hover:bg-blue-600 text-white font-bold text-xs rounded uppercase shadow-2xs cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload New Data</span>
                  </button>
                  <button
                    onClick={handleRestoreSampleData}
                    className="flex items-center space-x-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded border border-slate-300 uppercase cursor-pointer"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-slate-600" />
                    <span>Restore Sample Data</span>
                  </button>
                </div>
              </div>
            )}

            {/* Slicers & Filters */}
            {!isPresentationMode && records.length > 0 && (
              <FilterBar
                filters={filters}
                setFilters={setFilters}
                availableBrands={availableBrands}
                availableScenarios={availableScenarios}
                availableBUs={availableBUs}
                availableGrades={availableGrades}
                availableProcTypes={availableProcTypes}
                availableOmniLmds={availableOmniLmds}
                availableGIDates={availableGIDates}
                onResetFilters={handleResetFilters}
              />
            )}

            {/* Presentation Mode Control Tower Bar */}
            {isPresentationMode && (
              <div className="flex flex-wrap justify-between items-center bg-slate-900 border border-slate-800 p-3.5 rounded-lg shadow-md mb-4 text-white gap-3 no-print">
                <div className="flex items-center space-x-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
                  <div>
                    <span className="font-bold text-xs tracking-wider text-blue-400 uppercase font-mono block">
                      PRESENTATION CONTROL TOWER
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Design by Ronald Mpuuga | All rights reserved by mpuugasites.com
                    </span>
                  </div>
                </div>

                <div className="flex items-center flex-wrap gap-2">
                  {/* GI Date Selector in Presentation Bar */}
                  <div className="flex items-center space-x-2 bg-slate-800/90 px-3 py-1.5 rounded border border-slate-700 text-xs font-mono">
                    <Calendar className="w-3.5 h-3.5 text-blue-400" />
                    <span className="text-slate-300 font-bold hidden sm:inline">GI Date:</span>
                    <select
                      value={filters.goodsIssueStatusDate}
                      onChange={(e) => setFilters((prev) => ({ ...prev, goodsIssueStatusDate: e.target.value }))}
                      className="bg-slate-900 text-white font-bold px-2 py-1 rounded border border-slate-700 text-xs focus:outline-none focus:border-blue-500 cursor-pointer"
                    >
                      <option value="">All GI Dates</option>
                      {availableGIDates.map((dStr) => (
                        <option key={dStr} value={dStr}>
                          {dStr}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={() => exportToPowerPoint(stats, filteredRecords)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#2E5BFF] hover:bg-blue-600 text-white rounded text-xs font-bold font-mono uppercase cursor-pointer transition-all shadow-2xs"
                    title="Download Presentation directly as PowerPoint (.pptx)"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-300" />
                    <span>Download PPTX</span>
                  </button>

                  <button
                    onClick={() => exportToPDF('presentation-view-container', stats, filteredRecords)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-bold font-mono uppercase cursor-pointer transition-all shadow-2xs"
                    title="Download Presentation directly as PDF (.pdf)"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>

                  <button
                    onClick={() => triggerPrintPresentation()}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-bold font-mono uppercase cursor-pointer transition-all"
                    title="Print Presentation"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print</span>
                  </button>

                  <button
                    onClick={() => setIsPresentationExportOpen(true)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-bold font-mono uppercase cursor-pointer transition-all shadow-2xs"
                    title="Open Presentation Export & Print Center"
                  >
                    <Presentation className="w-3.5 h-3.5" />
                    <span>Export Menu</span>
                  </button>

                  <button
                    onClick={() => setIsPresentationMode(false)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-semibold cursor-pointer font-mono uppercase"
                  >
                    Exit Presentation
                  </button>
                </div>
              </div>
            )}

            {/* Real-time KPI Metric Cards */}
            <KPICards stats={stats} />

            {/* Dynamic View Switching */}
            {activeTab === 'dashboard' && (
              <DashboardView records={filteredRecords} stats={stats} />
            )}

            {activeTab === 'pivots' && <PivotView records={filteredRecords} />}

            {activeTab === 'categories' && (
              <CategoryBreakdownView records={filteredRecords} stats={stats} />
            )}

            {activeTab === 'schedule' && (
              <StoreScheduleView records={filteredRecords} />
            )}

            {activeTab === 'datatable' && <DataTable records={filteredRecords} />}

            {activeTab === 'vba' && (
              <div className="bg-white border border-[#E2E8F0] rounded p-6 text-[#1A1C1E] text-center space-y-4 shadow-xs">
                <div className="inline-block px-3 py-1 bg-blue-50 text-[#2E5BFF] font-mono text-xs font-bold uppercase rounded border border-blue-200">
                  COLLISION PROTECTION ENABLED
                </div>
                <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                  Excel VBA Macro Generator (Dynamic Safety Buffers)
                </h3>
                <p className="text-xs text-slate-600 max-w-xl mx-auto font-sans">
                  Configure row buffers, preview generated VBA script, and download the <code className="bg-slate-100 px-1.5 py-0.5 rounded text-[#2E5BFF] font-mono">.bas</code> file for seamless Excel execution without pivot overlap errors.
                </p>
                <button
                  onClick={() => setIsVBAOpen(true)}
                  className="px-5 py-2.5 bg-[#2E5BFF] hover:bg-blue-600 text-white font-bold text-xs rounded shadow-xs cursor-pointer font-mono uppercase tracking-wider"
                >
                  Open VBA Macro Script Builder
                </button>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Global Application Footer */}
      <footer className="bg-white border-t border-[#E2E8F0] py-3.5 px-4 text-center text-xs text-slate-500 font-mono shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-slate-600 font-medium">
            Design by <span className="font-bold text-slate-900">Ronald Mpuuga</span>
          </p>
          <p className="text-slate-500">
            All rights reserved by{' '}
            <a
              href="https://mpuugasites.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#2E5BFF] font-bold hover:underline"
            >
              mpuugasites.com
            </a>
          </p>
        </div>
      </footer>

      {/* Modals */}
      <DailyImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onUpdateRecords={handleUpdateRecords}
        totalRecords={records.length}
        onClearAllData={() => {
          setRecords([]);
          handleResetFilters();
          setIsImportOpen(false);
        }}
      />

      <VBAScriptModal
        isOpen={isVBAOpen}
        onClose={() => setIsVBAOpen(false)}
      />

      <PresentationExportModal
        isOpen={isPresentationExportOpen}
        onClose={() => setIsPresentationExportOpen(false)}
        stats={stats}
        records={filteredRecords}
      />
    </div>
  );
}

