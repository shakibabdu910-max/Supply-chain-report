export interface OBDORecord {
  id: string;
  obdo: string;
  erpDocument: string;
  brand: string; // e.g. NIKE, JRDN
  businessScenario: string; // e.g. RETUAE
  route: string;
  shipTo: string;
  shipToPartyDescription: string;
  toStorageLocation: string;
  stgeLocDescription: string;
  createdOn: string;
  createdAt: string;
  whseProcType: string;
  numberOfItems: number;
  sapObdItemTotalQty: number;
  ewmObdoItemTotalQty: number;
  packedQty: number;
  dpTotalQty: number;
  dnTotalQty: number;
  apparel: number;
  footwear: number;
  accessories: number;
  equipment: number;
  numberOfCartons: number;
  numberOfPallets: number;
  pickingStatusPlan: string;
  pickingStatusAct: string;
  packingStatus: string;
  actualPickingDate: string;
  packingDate: string;
  packingTime: string;
  plannedRouteDepartureDate: string;
  ownerOfStock: string;
  storageLocation: string;
  warehouseActivityStatus: string;
  transportationUnit: string;
  vehicle: string;
  loadingStatus: string;
  loadingDateAct: string;
  goodsIssueStatus: string;
  goodsIssueStatusDate: string;
  licensePlateNumber: string;
  driver: string;
  documentType: string;
  description: string;
  purchaseOrder: string;
  userComments: string;
  wave: string;
  pickingCompletionTime: string;
  deliveryPriority: number;
  businessUnit: string;
  omniActualLmd: string;
  storeGrade: string;
  releaseDate: string;
  releaseTime: string;
  mdcRemarks: string;
  deliveryOnDate: string;
  receiver: string;
  sfccNumber: string;
  cap: number;
  deliveryTime: string;
  frequency: string;
  weeklyCap: number;
}

export interface FilterState {
  brand: string;
  businessScenario: string;
  businessUnit: string;
  omniActualLmd: string;
  storeGrade: string;
  whseProcType: string;
  goodsIssueStatus: string;
  goodsIssueStatusDate: string;
  shipToParty: string;
  searchQuery: string;
  dateRangeStart: string;
  dateRangeEnd: string;
}

export interface KPIStats {
  totalOrders: number;
  totalEwmQty: number;
  totalPackedQty: number;
  totalDpQty: number;
  totalDnQty: number;
  totalCartons: number;
  totalPallets: number;
  totalApparel: number;
  totalFootwear: number;
  totalAccessories: number;
  totalEquipment: number;
  packingCompletionRate: number;
  totalWeeklyCap: number;
  totalDailyCap: number;
  capUtilizationRate: number;
  totalBusinessUnits: number;
  topBusinessUnit: string;
  activeOmniLmdCount: number;
  pendingOmniLmdCount: number;
}
