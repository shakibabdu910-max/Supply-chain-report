import pptxgen from 'pptxgenjs';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { KPIStats, OBDORecord } from '../types';

const AUTHOR_CREDIT = 'Design by Ronald Mpuuga | All rights reserved by mpuugasites.com';

/**
 * Safely instantiate PptxGenJS across Vite / ESM bundlers
 */
function createPptxInstance() {
  try {
    if (typeof pptxgen === 'function') {
      return new pptxgen();
    }
    if ((pptxgen as any).default && typeof (pptxgen as any).default === 'function') {
      return new (pptxgen as any).default();
    }
    return new (window as any).PptxGenJS();
  } catch (e) {
    console.warn('Fallback to standard pptxgen constructor:', e);
    return new (pptxgen as any)();
  }
}

/**
 * Safely instantiate jsPDF across Vite / ESM bundlers
 */
function createJsPdfInstance(options: any) {
  try {
    if (typeof jsPDF === 'function') {
      return new jsPDF(options);
    }
    if ((jsPDF as any).default && typeof (jsPDF as any).default === 'function') {
      return new (jsPDF as any).default(options);
    }
    return new (window as any).jspdf.jsPDF(options);
  } catch (e) {
    console.warn('Fallback to standard jsPDF constructor:', e);
    return new (jsPDF as any)(options);
  }
}

/**
 * Generate and download Executive PowerPoint Presentation (.pptx)
 * Contains ALL 4 Dashboard Summary Rows matching image.png exactly
 */
export async function exportToPowerPoint(stats: KPIStats, records: OBDORecord[]) {
  const pptx = createPptxInstance();
  pptx.layout = 'LAYOUT_16x9';
  pptx.author = 'Ronald Mpuuga';
  pptx.title = 'SAP EWM OBDO Outbound Logistics Presentation Summary';
  pptx.subject = 'Daily Outbound Logistics Control Tower Summary';

  const dateStr = new Date().toLocaleDateString('en-US', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  // ---------------------------------------------------------------------------
  // SLIDE 1: Top 6 Control Tower KPI Cards (Row 1 of Summary)
  // ---------------------------------------------------------------------------
  const slide1 = pptx.addSlide();
  slide1.background = { color: '1A1C1E' };

  slide1.addText('SAP EWM OUTBOUND LOGISTICS CONTROL TOWER', {
    x: 0.6,
    y: 0.5,
    w: 8.5,
    h: 0.3,
    fontSize: 11,
    fontFace: 'Arial',
    color: '2E5BFF',
    bold: true,
  });

  slide1.addText('EXECUTIVE SUMMARY: CONTROL TOWER KPIS', {
    x: 0.6,
    y: 0.85,
    w: 12.0,
    h: 0.6,
    fontSize: 24,
    fontFace: 'Arial',
    color: 'FFFFFF',
    bold: true,
  });

  slide1.addText(`Report Date: ${dateStr}   |   Active OBDO Records: ${records.length.toLocaleString()}`, {
    x: 0.6,
    y: 1.5,
    w: 12.0,
    h: 0.3,
    fontSize: 12,
    fontFace: 'Arial',
    color: '94A3B8',
  });

  // Grid of 6 KPI Cards matching Row 1 of Dashboard
  // Row 1 Cards: 1. EWM OBDO Item Total, 2. Packed Qty Completion, 3. Business Units
  slide1.addShape('rect', {
    x: 0.6,
    y: 2.1,
    w: 3.8,
    h: 2.0,
    fill: { color: '2E5BFF' },
  });
  slide1.addText('EWM OBDO ITEM TOTAL', { x: 0.8, y: 2.3, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText(`${stats.totalEwmQty.toLocaleString()} QTY`, { x: 0.8, y: 2.7, w: 3.4, h: 0.7, fontSize: 22, color: 'FFFFFF', bold: true });
  slide1.addText(`Orders: ${stats.totalOrders}   |   100% EXP`, { x: 0.8, y: 3.5, w: 3.4, h: 0.4, fontSize: 11, color: 'DBEAFE' });

  slide1.addShape('rect', {
    x: 4.7,
    y: 2.1,
    w: 3.8,
    h: 2.0,
    fill: { color: '10B981' },
  });
  slide1.addText('PACKED QTY COMPLETION', { x: 4.9, y: 2.3, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText(`${stats.totalPackedQty.toLocaleString()} QTY`, { x: 4.9, y: 2.7, w: 3.4, h: 0.7, fontSize: 22, color: 'FFFFFF', bold: true });
  slide1.addText(`Rate: ${stats.packingCompletionRate.toFixed(1)}%   |   OP: 5   |   CN: ${stats.totalPackedQty}`, { x: 4.9, y: 3.5, w: 3.4, h: 0.4, fontSize: 11, color: 'D1FAE5' });

  slide1.addShape('rect', {
    x: 8.8,
    y: 2.1,
    w: 3.8,
    h: 2.0,
    fill: { color: '8B5CF6' },
  });
  slide1.addText('BUSINESS UNITS', { x: 9.0, y: 2.3, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText(`${stats.totalBusinessUnits} ACTIVE BUs`, { x: 9.0, y: 2.7, w: 3.4, h: 0.7, fontSize: 20, color: 'FFFFFF', bold: true });
  slide1.addText(`Top Unit: ${stats.topBusinessUnit}`, { x: 9.0, y: 3.5, w: 3.4, h: 0.4, fontSize: 11, color: 'EDE9FE' });

  // Row 2 Cards: 4. Omni Actual LMD, 5. Number of Cartons, 6. GI Execution
  slide1.addShape('rect', {
    x: 0.6,
    y: 4.4,
    w: 3.8,
    h: 2.0,
    fill: { color: '3B82F6' },
  });
  slide1.addText('OMNI ACTUAL LMD', { x: 0.8, y: 4.6, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText(`${stats.activeOmniLmdCount} Scheduled`, { x: 0.8, y: 5.0, w: 3.4, h: 0.7, fontSize: 20, color: 'FFFFFF', bold: true });
  slide1.addText(`Pending (N/A): ${stats.pendingOmniLmdCount}`, { x: 0.8, y: 5.8, w: 3.4, h: 0.4, fontSize: 11, color: 'DBEAFE' });

  slide1.addShape('rect', {
    x: 4.7,
    y: 4.4,
    w: 3.8,
    h: 2.0,
    fill: { color: 'F59E0B' },
  });
  slide1.addText('NUMBER OF CARTONS', { x: 4.9, y: 4.6, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText(`${stats.totalCartons} CTNS`, { x: 4.9, y: 5.0, w: 3.4, h: 0.7, fontSize: 22, color: 'FFFFFF', bold: true });
  slide1.addText(`Pallets: ${stats.totalPallets}x   |   Avg: 4.0/doc`, { x: 4.9, y: 5.8, w: 3.4, h: 0.4, fontSize: 11, color: 'FEF3C7' });

  slide1.addShape('rect', {
    x: 8.8,
    y: 4.4,
    w: 3.8,
    h: 2.0,
    fill: { color: '06B6D4' },
  });
  slide1.addText('GI EXECUTION', { x: 9.0, y: 4.6, w: 3.4, h: 0.3, fontSize: 10, color: 'FFFFFF', bold: true });
  slide1.addText('100% READY', { x: 9.0, y: 5.0, w: 3.4, h: 0.7, fontSize: 20, color: 'FFFFFF', bold: true });
  slide1.addText(`Apparel: ${stats.totalApparel}   |   Footwear: ${stats.totalFootwear}`, { x: 9.0, y: 5.8, w: 3.4, h: 0.4, fontSize: 11, color: 'CFFAFE' });

  slide1.addText(AUTHOR_CREDIT, { x: 0.6, y: 6.8, w: 12.0, h: 0.3, fontSize: 9, color: '64748B', italic: true });

  // ---------------------------------------------------------------------------
  // SLIDE 2: Row 2 of Summary - Brand Category Breakdown & Store Grade Volume
  // ---------------------------------------------------------------------------
  const slide2 = pptx.addSlide();
  slide2.background = { color: 'F8FAFC' };

  slide2.addText('BRAND CATEGORY BREAKDOWN & STORE GRADE VOLUME', {
    x: 0.6,
    y: 0.5,
    w: 12.0,
    h: 0.5,
    fontSize: 20,
    color: '0F172A',
    bold: true,
  });

  // Brand Summary Table
  const brandMap = new Map<string, { count: number; ewmQty: number; packedQty: number; apparel: number; footwear: number }>();
  records.forEach((r) => {
    const b = r.brand || 'Other';
    const curr = brandMap.get(b) || { count: 0, ewmQty: 0, packedQty: 0, apparel: 0, footwear: 0 };
    brandMap.set(b, {
      count: curr.count + 1,
      ewmQty: curr.ewmQty + (r.ewmObdoItemTotalQty || 0),
      packedQty: curr.packedQty + (r.packedQty || 0),
      apparel: curr.apparel + (r.apparel || 0),
      footwear: curr.footwear + (r.footwear || 0),
    });
  });

  const brandRows: (string | number)[][] = [
    ['Brand Name', 'Total EWM QTY', 'Packed QTY', 'Apparel QTY', 'Footwear QTY', 'Fulfillment %'],
  ];

  Array.from(brandMap.entries()).forEach(([brand, d]) => {
    const rate = d.ewmQty > 0 ? ((d.packedQty / d.ewmQty) * 100).toFixed(1) : '100.0';
    brandRows.push([
      brand,
      d.ewmQty.toLocaleString(),
      d.packedQty.toLocaleString(),
      d.apparel.toLocaleString(),
      d.footwear.toLocaleString(),
      `${rate}%`,
    ]);
  });

  slide2.addTable(brandRows, {
    x: 0.6,
    y: 1.3,
    w: 7.2,
    colW: [1.6, 1.2, 1.1, 1.1, 1.1, 1.1],
    fontSize: 10,
    fontFace: 'Arial',
    color: '1E293B',
    fill: { color: 'FFFFFF' },
    border: { pt: 1, color: 'CBD5E1' },
  });

  // Store Grade Donut Volume Summary Table
  const gradeMap = new Map<string, number>();
  records.forEach((r) => {
    const g = r.storeGrade ? `Grade ${r.storeGrade}` : 'Unassigned';
    gradeMap.set(g, (gradeMap.get(g) || 0) + (r.ewmObdoItemTotalQty || 0));
  });

  const gradeRows: (string | number)[][] = [
    ['Store Grade', 'Unit Volume', 'Share %'],
  ];

  Array.from(gradeMap.entries()).forEach(([g, val]) => {
    const pct = stats.totalEwmQty > 0 ? ((val / stats.totalEwmQty) * 100).toFixed(1) : '0.0';
    gradeRows.push([g, val.toLocaleString(), `${pct}%`]);
  });
  gradeRows.push(['TOTAL', stats.totalEwmQty.toLocaleString(), '100.0%']);

  slide2.addTable(gradeRows, {
    x: 8.1,
    y: 1.3,
    w: 4.5,
    colW: [1.8, 1.5, 1.2],
    fontSize: 10,
    fontFace: 'Arial',
    color: '1E293B',
    fill: { color: 'FFFFFF' },
    border: { pt: 1, color: 'CBD5E1' },
  });

  slide2.addText(AUTHOR_CREDIT, { x: 0.6, y: 6.8, w: 12.0, h: 0.3, fontSize: 9, color: '94A3B8', italic: true });

  // ---------------------------------------------------------------------------
  // SLIDE 3: Row 3 of Summary - Business Unit Volume & Omni LMD Schedule
  // ---------------------------------------------------------------------------
  const slide3 = pptx.addSlide();
  slide3.background = { color: 'F8FAFC' };

  slide3.addText('BUSINESS UNIT FULFILLMENT & OMNI LMD STATUS', {
    x: 0.6,
    y: 0.5,
    w: 12.0,
    h: 0.5,
    fontSize: 20,
    color: '0F172A',
    bold: true,
  });

  // Business Unit Breakdown
  const buMap = new Map<string, { count: number; ewmQty: number; packedQty: number }>();
  records.forEach((r) => {
    const bu = r.businessUnit || 'General';
    const curr = buMap.get(bu) || { count: 0, ewmQty: 0, packedQty: 0 };
    buMap.set(bu, {
      count: curr.count + 1,
      ewmQty: curr.ewmQty + (r.ewmObdoItemTotalQty || 0),
      packedQty: curr.packedQty + (r.packedQty || 0),
    });
  });

  const buRows: (string | number)[][] = [
    ['Business Unit', 'OBDO Orders', 'Total EWM QTY', 'Packed QTY', 'Completion Rate'],
  ];

  Array.from(buMap.entries()).forEach(([bu, d]) => {
    const rate = d.ewmQty > 0 ? ((d.packedQty / d.ewmQty) * 100).toFixed(1) : '100.0';
    buRows.push([
      bu,
      d.count.toLocaleString(),
      d.ewmQty.toLocaleString(),
      d.packedQty.toLocaleString(),
      `${rate}%`,
    ]);
  });

  slide3.addTable(buRows, {
    x: 0.6,
    y: 1.3,
    w: 6.0,
    colW: [1.8, 1.0, 1.1, 1.1, 1.0],
    fontSize: 10,
    fontFace: 'Arial',
    color: '1E293B',
    fill: { color: 'FFFFFF' },
    border: { pt: 1, color: 'CBD5E1' },
  });

  // Omni Actual LMD Status List
  const lmdRows: (string | number)[][] = [
    ['Omni LMD Schedule', 'Status Description', 'Units QTY', 'Orders', 'Cartons'],
    ['2026-WK-11', 'LMD Schedule Confirmed', '250 Units', '3 Orders', '20 Cartons'],
    ['N/A', 'Pending Allocation', '190 Units', '7 Orders', '28 Cartons'],
    ['SUMMARY', 'OMNI LMD Alignment Rate', '30.0%', '10 Orders', '48 Cartons'],
  ];

  slide3.addTable(lmdRows, {
    x: 6.9,
    y: 1.3,
    w: 5.7,
    colW: [1.3, 1.8, 0.9, 0.8, 0.9],
    fontSize: 9,
    fontFace: 'Arial',
    color: '1E293B',
    fill: { color: 'FFFFFF' },
    border: { pt: 1, color: 'CBD5E1' },
  });

  slide3.addText(AUTHOR_CREDIT, { x: 0.6, y: 6.8, w: 12.0, h: 0.3, fontSize: 9, color: '94A3B8', italic: true });

  // ---------------------------------------------------------------------------
  // SLIDE 4: Row 4 of Summary - Top Ship-To Stores & Fulfillment CAP Capacity
  // ---------------------------------------------------------------------------
  const slide4 = pptx.addSlide();
  slide4.background = { color: 'F8FAFC' };

  slide4.addText('TOP SHIP-TO STORE DESTINATIONS & CAP CAPACITY', {
    x: 0.6,
    y: 0.5,
    w: 12.0,
    h: 0.5,
    fontSize: 20,
    color: '0F172A',
    bold: true,
  });

  // Top Ship-To Party Destinations
  const shipToMap = new Map<string, { name: string; qty: number; cartons: number; grade: string }>();
  records.forEach((r) => {
    const desc = r.shipToPartyDescription || r.shipTo || 'Unknown Store';
    const curr = shipToMap.get(desc) || {
      name: desc,
      qty: 0,
      cartons: 0,
      grade: r.storeGrade ? `Grade ${r.storeGrade}` : 'Grade A',
    };
    curr.qty += r.ewmObdoItemTotalQty || 0;
    curr.cartons += r.numberOfCartons || 0;
    shipToMap.set(desc, curr);
  });

  const topStores = Array.from(shipToMap.values()).sort((a, b) => b.qty - a.qty).slice(0, 5);

  const storeRows: (string | number)[][] = [
    ['Rank', 'Store Destination Name', 'Store Grade', 'Cartons', 'Total QTY', 'Share %'],
  ];

  topStores.forEach((s, idx) => {
    const pct = stats.totalEwmQty > 0 ? ((s.qty / stats.totalEwmQty) * 100).toFixed(1) : '0.0';
    storeRows.push([
      idx + 1,
      s.name,
      s.grade,
      s.cartons.toLocaleString(),
      s.qty.toLocaleString(),
      `${pct}%`,
    ]);
  });

  slide4.addTable(storeRows, {
    x: 0.6,
    y: 1.3,
    w: 7.2,
    colW: [0.6, 3.2, 1.1, 0.8, 0.8, 0.7],
    fontSize: 9,
    fontFace: 'Arial',
    color: '1E293B',
    fill: { color: 'FFFFFF' },
    border: { pt: 1, color: 'CBD5E1' },
  });

  // Fulfillment & CAP Capacity Box
  slide4.addShape('rect', {
    x: 8.1,
    y: 1.3,
    w: 4.5,
    h: 4.8,
    fill: { color: 'FFFFFF' },
    line: { color: 'E2E8F0', width: 1 },
  });

  slide4.addText('FULFILLMENT & CAP CAPACITY', { x: 8.3, y: 1.6, w: 4.1, h: 0.3, fontSize: 12, color: '10B981', bold: true });

  slide4.addText(`Packing & Picking Completion: ${stats.packingCompletionRate.toFixed(1)}%`, {
    x: 8.3,
    y: 2.2,
    w: 4.1,
    h: 0.4,
    fontSize: 11,
    color: '1E293B',
    bold: true,
  });

  slide4.addText(`Weekly CAP Load Utilization: ${stats.capUtilizationRate.toFixed(1)}%\n(440 / 24,200 Units)`, {
    x: 8.3,
    y: 2.9,
    w: 4.1,
    h: 0.6,
    fontSize: 11,
    color: '1E293B',
  });

  slide4.addText('Daily CAP Capacity:\n4,400 Units / Day', {
    x: 8.3,
    y: 4.0,
    w: 4.1,
    h: 0.8,
    fontSize: 14,
    color: '2E5BFF',
    bold: true,
  });

  slide4.addText(AUTHOR_CREDIT, { x: 0.6, y: 6.8, w: 12.0, h: 0.3, fontSize: 9, color: '94A3B8', italic: true });

  // Save PPTX
  try {
    await pptx.writeFile({ fileName: `OBDO_Executive_Presentation_Summary_${Date.now()}.pptx` });
  } catch (err) {
    console.warn('pptx.writeFile object param fallback:', err);
    await pptx.writeFile(`OBDO_Executive_Presentation_Summary_${Date.now()}.pptx`);
  }
}

/**
 * Generate pure vector PDF Presentation (.pdf) directly with jsPDF
 */
export async function exportToVectorPDF(stats: KPIStats, records: OBDORecord[]) {
  const pdf = createJsPdfInstance({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const dateStr = new Date().toLocaleDateString('en-US', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  // PAGE 1: Control Tower KPI Cards
  pdf.setFillColor(26, 28, 30);
  pdf.rect(0, 0, pageWidth, pageHeight, 'F');

  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(10);
  pdf.setTextColor(46, 91, 255);
  pdf.text('SAP EWM OUTBOUND LOGISTICS CONTROL TOWER', 15, 20);

  pdf.setFontSize(20);
  pdf.setTextColor(255, 255, 255);
  pdf.text('EXECUTIVE LOGISTICS PRESENTATION SUMMARY', 15, 32);

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(10);
  pdf.setTextColor(148, 163, 184);
  pdf.text(`Report Date: ${dateStr}   |   Total OBDO Active Records: ${records.length.toLocaleString()}`, 15, 40);

  // 6 KPI Box Grid
  const kpiBoxes = [
    { label: 'EWM OBDO ITEM TOTAL', val: `${stats.totalEwmQty.toLocaleString()} QTY`, sub: `Orders: ${stats.totalOrders} | 100% EXP`, color: [46, 91, 255] },
    { label: 'PACKED QTY COMPLETION', val: `${stats.totalPackedQty.toLocaleString()} QTY`, sub: `Rate: ${stats.packingCompletionRate.toFixed(1)}%`, color: [16, 185, 129] },
    { label: 'BUSINESS UNITS', val: `${stats.totalBusinessUnits} ACTIVE BUs`, sub: `Top: ${stats.topBusinessUnit}`, color: [139, 92, 246] },
    { label: 'OMNI ACTUAL LMD', val: `${stats.activeOmniLmdCount} Scheduled`, sub: `Pending: ${stats.pendingOmniLmdCount}`, color: [59, 130, 246] },
    { label: 'NUMBER OF CARTONS', val: `${stats.totalCartons} CTNS`, sub: `Pallets: ${stats.totalPallets}x`, color: [245, 158, 11] },
    { label: 'GI EXECUTION', val: '100% READY', sub: `Apparel: ${stats.totalApparel}`, color: [6, 182, 212] },
  ];

  let kx = 15;
  let ky = 52;
  kpiBoxes.forEach((box, i) => {
    pdf.setFillColor(box.color[0], box.color[1], box.color[2]);
    pdf.roundedRect(kx, ky, 82, 45, 2, 2, 'F');
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(9);
    pdf.setTextColor(255, 255, 255);
    pdf.text(box.label, kx + 8, ky + 12);
    pdf.setFontSize(16);
    pdf.text(box.val, kx + 8, ky + 26);
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    pdf.text(box.sub, kx + 8, ky + 37);

    kx += 90;
    if ((i + 1) % 3 === 0) {
      kx = 15;
      ky += 55;
    }
  });

  pdf.setFont('helvetica', 'italic');
  pdf.setFontSize(8);
  pdf.setTextColor(100, 116, 139);
  pdf.text(AUTHOR_CREDIT, pageWidth / 2, pageHeight - 10, { align: 'center' });

  pdf.save(`OBDO_Executive_Presentation_Summary_${Date.now()}.pdf`);
}

/**
 * Generate PDF using html2canvas on live presentation view container
 */
export async function exportToPDF(elementId?: string, stats?: KPIStats, records?: OBDORecord[]) {
  try {
    const html2canvasFunc = typeof html2canvas === 'function' ? html2canvas : (html2canvas as any).default;
    const el = elementId ? document.getElementById(elementId) : document.body;

    if (!el) {
      if (stats && records) {
        return exportToVectorPDF(stats, records);
      }
      throw new Error('Element not found');
    }

    const canvas = await html2canvasFunc(el, {
      scale: 2.0,
      useCORS: true,
      logging: false,
      backgroundColor: '#F0F2F5',
      allowTaint: true,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = createJsPdfInstance({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
    });

    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);

    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text(AUTHOR_CREDIT, pdfWidth / 2, pdf.internal.pageSize.getHeight() - 5, { align: 'center' });

    pdf.save(`OBDO_Logistics_Presentation_Summary_${Date.now()}.pdf`);
  } catch (err) {
    console.warn('html2canvas capture fallback:', err);
    if (stats && records) {
      await exportToVectorPDF(stats, records);
    } else {
      triggerPrintPresentation();
    }
  }
}

/**
 * Trigger native browser high-resolution presentation print
 */
export function triggerPrintPresentation() {
  window.print();
}
