import { OBDORecord, FilterState, KPIStats } from '../types';

export function calculateKPIs(records: OBDORecord[]): KPIStats {
  const totalOrders = records.length;
  let totalEwmQty = 0;
  let totalPackedQty = 0;
  let totalDpQty = 0;
  let totalDnQty = 0;
  let totalCartons = 0;
  let totalPallets = 0;
  let totalApparel = 0;
  let totalFootwear = 0;
  let totalAccessories = 0;
  let totalEquipment = 0;
  let totalWeeklyCap = 0;
  let totalDailyCap = 0;

  // Track Business Units and OMNI LMDs
  const buCountMap = new Map<string, number>();
  let activeOmniLmdCount = 0;
  let pendingOmniLmdCount = 0;

  // Use a map to track unique store caps so we don't overcount weekly cap per store
  const storeCapMap = new Map<string, { cap: number; weeklyCap: number }>();

  records.forEach((r) => {
    totalEwmQty += Number(r.ewmObdoItemTotalQty) || 0;
    totalPackedQty += Number(r.packedQty) || 0;
    totalDpQty += Number(r.dpTotalQty) || 0;
    totalDnQty += Number(r.dnTotalQty) || 0;
    totalCartons += Number(r.numberOfCartons) || 0;
    totalPallets += Number(r.numberOfPallets) || 0;

    totalApparel += Number(r.apparel) || 0;
    totalFootwear += Number(r.footwear) || 0;
    totalAccessories += Number(r.accessories) || 0;
    totalEquipment += Number(r.equipment) || 0;

    const bu = r.businessUnit || 'General';
    buCountMap.set(bu, (buCountMap.get(bu) || 0) + (Number(r.ewmObdoItemTotalQty) || 0));

    const lmd = (r.omniActualLmd || '').trim();
    if (!lmd || lmd === '#N/A' || lmd === 'N/A' || lmd === 'Pending') {
      pendingOmniLmdCount += 1;
    } else {
      activeOmniLmdCount += 1;
    }

    if (r.shipTo && !storeCapMap.has(r.shipTo)) {
      storeCapMap.set(r.shipTo, {
        cap: Number(r.cap) || 0,
        weeklyCap: Number(r.weeklyCap) || 0,
      });
    }
  });

  storeCapMap.forEach((val) => {
    totalDailyCap += val.cap;
    totalWeeklyCap += val.weeklyCap;
  });

  const packingCompletionRate =
    totalEwmQty > 0 ? (totalPackedQty / totalEwmQty) * 100 : 0;
  const capUtilizationRate =
    totalWeeklyCap > 0 ? (totalEwmQty / totalWeeklyCap) * 100 : 0;

  // Find Top Business Unit
  let topBusinessUnit = 'N/A';
  let maxBuQty = -1;
  buCountMap.forEach((qty, bu) => {
    if (qty > maxBuQty) {
      maxBuQty = qty;
      topBusinessUnit = bu;
    }
  });

  return {
    totalOrders,
    totalEwmQty,
    totalPackedQty,
    totalDpQty,
    totalDnQty,
    totalCartons,
    totalPallets,
    totalApparel,
    totalFootwear,
    totalAccessories,
    totalEquipment,
    packingCompletionRate,
    totalWeeklyCap,
    totalDailyCap,
    capUtilizationRate,
    totalBusinessUnits: buCountMap.size,
    topBusinessUnit,
    activeOmniLmdCount,
    pendingOmniLmdCount,
  };
}

export function normalizeDateString(dateStr: string | null | undefined): string {
  if (!dateStr) return '';
  const trimmed = dateStr.trim();
  if (!trimmed) return '';

  // Handle YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) {
    return trimmed.slice(0, 10);
  }

  // Handle DD/MM/YYYY or MM/DD/YYYY or DD.MM.YYYY
  const parts = trimmed.split(/[/.-]/);
  if (parts.length === 3) {
    let [p1, p2, p3] = parts;
    // e.g. 11/08/2026 -> p1=11, p2=08, p3=2026
    if (p3.length === 4) {
      let month = p2.padStart(2, '0');
      let day = p1.padStart(2, '0');
      if (Number(p1) <= 12 && Number(p2) > 12) {
        month = p1.padStart(2, '0');
        day = p2.padStart(2, '0');
      }
      return `${p3}-${month}-${day}`;
    }
    // e.g. 2026/08/11 -> p1=2026, p2=08, p3=11
    if (p1.length === 4) {
      return `${p1}-${p2.padStart(2, '0')}-${p3.padStart(2, '0')}`;
    }
  }

  const d = new Date(trimmed);
  if (!isNaN(d.getTime())) {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  return trimmed;
}

export function filterRecords(
  records: OBDORecord[],
  filters: FilterState
): OBDORecord[] {
  return records.filter((r) => {
    if (filters.brand && r.brand !== filters.brand) return false;
    if (
      filters.businessScenario &&
      r.businessScenario !== filters.businessScenario
    )
      return false;
    if (filters.businessUnit && r.businessUnit !== filters.businessUnit)
      return false;
    if (filters.omniActualLmd && r.omniActualLmd !== filters.omniActualLmd)
      return false;
    if (filters.storeGrade && r.storeGrade !== filters.storeGrade)
      return false;
    if (filters.whseProcType && r.whseProcType !== filters.whseProcType)
      return false;
    if (
      filters.goodsIssueStatus &&
      r.goodsIssueStatus !== filters.goodsIssueStatus
    )
      return false;

    // Filter by Goods Issue Status Date (Calendar Selection)
    if (filters.goodsIssueStatusDate) {
      const targetNorm = normalizeDateString(filters.goodsIssueStatusDate);
      const recordNorm = normalizeDateString(r.goodsIssueStatusDate || r.actualPickingDate || r.createdOn);
      const isExactMatch = r.goodsIssueStatusDate === filters.goodsIssueStatusDate;
      if (!isExactMatch && recordNorm !== targetNorm) {
        return false;
      }
    }

    if (
      filters.shipToParty &&
      !r.shipToPartyDescription
        .toLowerCase()
        .includes(filters.shipToParty.toLowerCase())
    )
      return false;

    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      const match =
        r.obdo.toLowerCase().includes(q) ||
        r.erpDocument.toLowerCase().includes(q) ||
        r.brand.toLowerCase().includes(q) ||
        (r.businessUnit && r.businessUnit.toLowerCase().includes(q)) ||
        (r.omniActualLmd && r.omniActualLmd.toLowerCase().includes(q)) ||
        (r.goodsIssueStatusDate && r.goodsIssueStatusDate.toLowerCase().includes(q)) ||
        r.shipToPartyDescription.toLowerCase().includes(q) ||
        r.driver.toLowerCase().includes(q) ||
        r.userComments.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });
}
