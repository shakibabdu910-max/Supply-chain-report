export function generateVBAMacro(spacingBuffer: number = 12): string {
  return `' ==============================================================================
' AUTOMATED OBDO LOGISTICS DASHBOARD & PIVOT GENERATOR
' Design by Ronald Mpuuga | All rights reserved by mpuugasites.com
' Designed for Daily Executive Presentation & OBDO Supply Chain Tracking
' Includes Collision-Proof Pivot Column Blocks & Dynamic Dashboard Buffer
' ==============================================================================

Option Explicit

Public Sub Build_Professional_OBDO_Dashboard()
    Dim wsData As Worksheet
    Dim wsDash As Worksheet
    Dim wsPiv1 As Worksheet, wsPiv2 As Worksheet, wsPiv3 As Worksheet, wsPiv4 As Worksheet
    Dim pcCache As PivotCache
    Dim ptBrand As PivotTable
    Dim ptBU As PivotTable
    Dim ptProc As PivotTable
    Dim ptShipTo As PivotTable
    Dim lastRow As Long
    Dim lastCol As Long
    Dim dataRange As Range
    Dim spacing As Long
    Dim dataSheetName As String
    Dim dashNextRow As Long
    Dim lastDashRow As Long
    Dim wsItem As Worksheet
    
    ' Header Name Variables (Dynamic Resolution to prevent Error 1004)
    Dim fldBrand As String, fldScenario As String, fldBU As String, fldGrade As String
    Dim fldEwmQty As String, fldPackedQty As String, fldApparel As String, fldFootwear As String
    Dim fldAcc As String, fldCartons As String, fldPallets As String
    Dim fldProcType As String, fldObdoDoc As String, fldDpQty As String, fldDnQty As String
    Dim fldShipTo As String, fldDelTime As String, fldFreq As String, fldCap As String, fldWkCap As String
    
    Dim sumEwm As Double, sumPacked As Double, sumCartons As Double, sumPallets As Double
    Dim sumApparel As Double, sumFootwear As Double
    
    On Error GoTo ErrorHandler
    
    ' Speed Optimization
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Application.DisplayAlerts = False

    spacing = ${spacingBuffer} ' Row buffer spacing between pivot table sections on Dashboard

    ' 1. Check or Setup Worksheets (Fallback to ActiveSheet if 'Data' sheet renamed)
    On Error Resume Next
    Set wsData = ActiveWorkbook.Worksheets("Data")
    If wsData Is Nothing Then
        Set wsData = ActiveSheet
    End If
    On Error GoTo ErrorHandler
    
    dataSheetName = wsData.Name

    ' Determine Data Source Bounds
    lastRow = wsData.Cells(wsData.Rows.Count, 1).End(xlUp).Row
    lastCol = wsData.Cells(1, wsData.Columns.Count).End(xlToLeft).Column
    
    If lastRow < 2 Then
        MsgBox "Data sheet '" & dataSheetName & "' contains no data rows!", vbExclamation, "No Data Found"
        GoTo CleanUp
    End If
    
    Set dataRange = wsData.Range(wsData.Cells(1, 1), wsData.Cells(lastRow, lastCol))

    ' 2. Dynamically Resolve Header Names (Prevents Error 1004 on mismatched spaces/case)
    fldBrand = FindHeader(wsData, "Brand")
    fldScenario = FindHeader(wsData, "Business Scenario", "Scenario")
    fldBU = FindHeader(wsData, "Business Unit", "BU")
    fldGrade = FindHeader(wsData, "Store Grade", "Grade")
    fldEwmQty = FindHeader(wsData, "EWM OBDO Item", "EWM QTY", "EWM")
    fldPackedQty = FindHeader(wsData, "Packed QTY", "Packed")
    fldApparel = FindHeader(wsData, "Apparel")
    fldFootwear = FindHeader(wsData, "Footwear")
    fldAcc = FindHeader(wsData, "Accessories")
    fldCartons = FindHeader(wsData, "Number of Cartons", "Cartons")
    fldPallets = FindHeader(wsData, "Number of Pallets", "Pallets")
    fldProcType = FindHeader(wsData, "Whse Proc. Type", "Whse Proc", "Proc. Type")
    fldObdoDoc = FindHeader(wsData, "Document (OBDO)", "OBDO", "Document")
    fldDpQty = FindHeader(wsData, "DP total Qty", "DP Qty", "DP")
    fldDnQty = FindHeader(wsData, "DN Total Qty", "DN Qty", "DN")
    fldShipTo = FindHeader(wsData, "Ship-To Party Description", "Ship-To", "Ship To")
    fldDelTime = FindHeader(wsData, "Delivery Time", "Time")
    fldFreq = FindHeader(wsData, "Frequency")
    fldCap = FindHeader(wsData, "CAP")
    fldWkCap = FindHeader(wsData, "Weekly CAP")

    ' 3. Safely Remove Previous Dashboard & Engine Worksheets
    On Error Resume Next
    For Each wsItem In ActiveWorkbook.Worksheets
        If wsItem.Name = "OBDO_Dashboard" _
           Or wsItem.Name = "Pivot_Engine" _
           Or wsItem.Name = "PivEngine_1" _
           Or wsItem.Name = "PivEngine_2" _
           Or wsItem.Name = "PivEngine_3" _
           Or wsItem.Name = "PivEngine_4" Then
            wsItem.Delete
        End If
    Next wsItem
    On Error GoTo ErrorHandler

    ' Create Fresh Worksheets
    Set wsDash = ActiveWorkbook.Worksheets.Add(Before:=wsData)
    wsDash.Name = "OBDO_Dashboard"
    
    Set wsPiv1 = ActiveWorkbook.Worksheets.Add(After:=wsDash)
    wsPiv1.Name = "PivEngine_1"
    
    Set wsPiv2 = ActiveWorkbook.Worksheets.Add(After:=wsPiv1)
    wsPiv2.Name = "PivEngine_2"
    
    Set wsPiv3 = ActiveWorkbook.Worksheets.Add(After:=wsPiv2)
    wsPiv3.Name = "PivEngine_3"
    
    Set wsPiv4 = ActiveWorkbook.Worksheets.Add(After:=wsPiv3)
    wsPiv4.Name = "PivEngine_4"

    ' 4. Create Pivot Cache
    Set pcCache = ActiveWorkbook.PivotCaches.Create( _
        SourceType:=xlDatabase, _
        SourceData:=dataRange.Address(True, True, xlA1, True, True))

    ' 5. Calculate KPI Summary Values Safely in VBA
    sumEwm = SumHeaderColumn(wsData, fldEwmQty, lastRow)
    sumPacked = SumHeaderColumn(wsData, fldPackedQty, lastRow)
    sumCartons = SumHeaderColumn(wsData, fldCartons, lastRow)
    sumPallets = SumHeaderColumn(wsData, fldPallets, lastRow)
    sumApparel = SumHeaderColumn(wsData, fldApparel, lastRow)
    sumFootwear = SumHeaderColumn(wsData, fldFootwear, lastRow)

    ' 6. Build Title Header Block on Dashboard
    With wsDash
        .Range("A1:N2").Merge
        .Range("A1").Value = "OBDO LOGISTICS & SUPPLY CHAIN EXECUTIVE DASHBOARD"
        .Range("A1").Font.Name = "Calibri"
        .Range("A1").Font.Size = 18
        .Range("A1").Font.Bold = True
        .Range("A1").Font.Color = RGB(255, 255, 255)
        .Range("A1").Interior.Color = RGB(27, 94, 32) ' Executive Dark Green Theme
        .Range("A1").HorizontalAlignment = xlHAlignCenter
        .Range("A1").VerticalAlignment = xlVAlignCenter

        ' Subtitle / Last Update Timestamp & Credits
        .Range("A3:N3").Merge
        .Range("A3").Value = "Report Date: " & Format(Now(), "DD-MMM-YYYY HH:MM") & "  |  Total OBDO Records: " & (lastRow - 1) & "  |  Design by Ronald Mpuuga (mpuugasites.com)"
        .Range("A3").Font.Italic = True
        .Range("A3").Font.Size = 10
        .Range("A3").Font.Color = RGB(100, 100, 100)
        .Range("A3").HorizontalAlignment = xlHAlignCenter

        ' Create KPI Presentation Cards (Row 5 to Row 7)
        Call FormatKPICard(wsDash, "B5:D7", "TOTAL EWM OBDO QTY", Format(sumEwm, "#,##0") & " QTY", RGB(232, 245, 233), RGB(46, 125, 50))
        Call FormatKPICard(wsDash, "E5:G7", "PACKED QTY COMPLETION", Format(sumPacked, "#,##0") & " Packed", RGB(227, 242, 253), RGB(21, 101, 192))
        Call FormatKPICard(wsDash, "H5:J7", "TOTAL CARTONS & PALLETS", Format(sumCartons, "#,##0") & " Ctns / " & Format(sumPallets, "#,##0") & " Plts", RGB(255, 243, 224), RGB(230, 81, 0))
        Call FormatKPICard(wsDash, "K5:M7", "APPAREL & FOOTWEAR", Format(sumApparel, "#,##0") & " App / " & Format(sumFootwear, "#,##0") & " Ftwr", RGB(243, 229, 245), RGB(106, 27, 154))
    End With

    ' ==============================================================================
    ' 7. PIVOT TABLE GENERATION IN DEDICATED ENGINE WORKSHEETS (100% COLLISION-PROOF)
    ' ==============================================================================
    
    ' --- PIVOT 1: Brand & Category Summary ---
    wsPiv1.Activate
    Set ptBrand = pcCache.CreatePivotTable( _
        TableDestination:=wsPiv1.Cells(2, 1), _
        TableName:="ptBrandSummary")
    
    With ptBrand
        If fldBrand <> "" Then .PivotFields(fldBrand).Orientation = xlRowField
        If fldScenario <> "" Then .PivotFields(fldScenario).Orientation = xlPageField
        
        If fldEwmQty <> "" Then .AddDataField .PivotFields(fldEwmQty), SafeCaption("Sum of EWM QTY", fldEwmQty), xlSum
        If fldPackedQty <> "" Then .AddDataField .PivotFields(fldPackedQty), SafeCaption("Sum of Packed QTY", fldPackedQty), xlSum
        If fldApparel <> "" Then .AddDataField .PivotFields(fldApparel), SafeCaption("Sum of Apparel", fldApparel), xlSum
        If fldFootwear <> "" Then .AddDataField .PivotFields(fldFootwear), SafeCaption("Sum of Footwear", fldFootwear), xlSum
        If fldAcc <> "" Then .AddDataField .PivotFields(fldAcc), SafeCaption("Sum of Accessories", fldAcc), xlSum
        If fldCartons <> "" Then .AddDataField .PivotFields(fldCartons), SafeCaption("Sum of Cartons", fldCartons), xlSum
    End With

    ' --- PIVOT 2: Business Unit & Store Grade Performance ---
    wsPiv2.Activate
    Set ptBU = pcCache.CreatePivotTable( _
        TableDestination:=wsPiv2.Cells(2, 1), _
        TableName:="ptBUSummary")
    
    With ptBU
        If fldBU <> "" Then .PivotFields(fldBU).Orientation = xlRowField
        If fldGrade <> "" Then .PivotFields(fldGrade).Orientation = xlColumnField
        If fldEwmQty <> "" Then .AddDataField .PivotFields(fldEwmQty), SafeCaption("EWM Qty Summary", fldEwmQty), xlSum
        If fldCap <> "" Then .AddDataField .PivotFields(fldCap), SafeCaption("Store CAP Avg", fldCap), xlAverage
        If fldWkCap <> "" Then .AddDataField .PivotFields(fldWkCap), SafeCaption("Weekly CAP Avg", fldWkCap), xlAverage
    End With

    ' --- PIVOT 3: Warehouse Proc Type Summary ---
    wsPiv3.Activate
    Set ptProc = pcCache.CreatePivotTable( _
        TableDestination:=wsPiv3.Cells(2, 1), _
        TableName:="ptProcTypeSummary")
    
    With ptProc
        If fldProcType <> "" Then .PivotFields(fldProcType).Orientation = xlRowField
        If fldObdoDoc <> "" Then .AddDataField .PivotFields(fldObdoDoc), SafeCaption("Count of OBDO", fldObdoDoc), xlCount
        If fldEwmQty <> "" Then .AddDataField .PivotFields(fldEwmQty), SafeCaption("Total EWM QTY", fldEwmQty), xlSum
        If fldPackedQty <> "" Then .AddDataField .PivotFields(fldPackedQty), SafeCaption("Total Packed QTY", fldPackedQty), xlSum
        If fldDpQty <> "" Then .AddDataField .PivotFields(fldDpQty), SafeCaption("Total DP QTY", fldDpQty), xlSum
        If fldDnQty <> "" Then .AddDataField .PivotFields(fldDnQty), SafeCaption("Total DN QTY", fldDnQty), xlSum
    End With

    ' --- PIVOT 4: Ship-To Party & Schedule Summary ---
    wsPiv4.Activate
    Set ptShipTo = pcCache.CreatePivotTable( _
        TableDestination:=wsPiv4.Cells(2, 1), _
        TableName:="ptShipToSummary")
    
    With ptShipTo
        If fldShipTo <> "" Then .PivotFields(fldShipTo).Orientation = xlRowField
        If fldDelTime <> "" Then .PivotFields(fldDelTime).Orientation = xlPageField
        If fldFreq <> "" Then .PivotFields(fldFreq).Orientation = xlPageField
        If fldEwmQty <> "" Then .AddDataField .PivotFields(fldEwmQty), SafeCaption("Ship-To EWM QTY", fldEwmQty), xlSum
        If fldCartons <> "" Then .AddDataField .PivotFields(fldCartons), SafeCaption("Ship-To Cartons", fldCartons), xlSum
    End With

    ' ==============================================================================
    ' 8. COPY FORMATTED PIVOT TABLES TO PRESENTATION DASHBOARD WITH SAFE SPACING
    ' ==============================================================================
    
    ' Section 1 & 2 Headers (Top Row 9)
    wsDash.Range("A9").Value = "1. BRAND & CATEGORY BREAKDOWN SUMMARY"
    wsDash.Range("A9").Font.Bold = True
    wsDash.Range("A9").Font.Size = 12
    wsDash.Range("A9").Font.Color = RGB(27, 94, 32)
    ptBrand.TableRange2.Copy wsDash.Range("A10")

    wsDash.Range("I9").Value = "2. BUSINESS UNIT & STORE GRADE SUMMARY"
    wsDash.Range("I9").Font.Bold = True
    wsDash.Range("I9").Font.Size = 12
    wsDash.Range("I9").Font.Color = RGB(27, 94, 32)
    ptBU.TableRange2.Copy wsDash.Range("I10")

    ' Calculate True Last Used Row on Dashboard across ALL columns + Add Generous Buffer
    lastDashRow = GetLastRowOnSheet(wsDash)
    If lastDashRow < 10 Then lastDashRow = 10
    dashNextRow = lastDashRow + spacing + 3 ' Generous row spacing buffer

    ' Section 3 & 4 Headers & Tables
    wsDash.Cells(dashNextRow - 1, 1).Value = "3. WAREHOUSE PROC TYPE & GOODS ISSUE SUMMARY"
    wsDash.Cells(dashNextRow - 1, 1).Font.Bold = True
    wsDash.Cells(dashNextRow - 1, 1).Font.Size = 12
    wsDash.Cells(dashNextRow - 1, 1).Font.Color = RGB(27, 94, 32)
    ptProc.TableRange2.Copy wsDash.Cells(dashNextRow, 1)

    wsDash.Cells(dashNextRow - 1, 9).Value = "4. SHIP-TO PARTY & CAP DELIVERY SCHEDULE"
    wsDash.Cells(dashNextRow - 1, 9).Font.Bold = True
    wsDash.Cells(dashNextRow - 1, 9).Font.Size = 12
    wsDash.Cells(dashNextRow - 1, 9).Font.Color = RGB(27, 94, 32)
    ptShipTo.TableRange2.Copy wsDash.Cells(dashNextRow, 9)

    ' Hide backend pivot engine worksheets after copy completes
    wsPiv1.Visible = xlSheetHidden
    wsPiv2.Visible = xlSheetHidden
    wsPiv3.Visible = xlSheetHidden
    wsPiv4.Visible = xlSheetHidden

    ' Add Dashboard Bottom Footer Credits
    lastDashRow = GetLastRowOnSheet(wsDash) + 3
    wsDash.Range(wsDash.Cells(lastDashRow, 1), wsDash.Cells(lastDashRow, 14)).Merge
    wsDash.Cells(lastDashRow, 1).Value = "Design by Ronald Mpuuga  |  All rights reserved by mpuugasites.com"
    wsDash.Cells(lastDashRow, 1).Font.Size = 9
    wsDash.Cells(lastDashRow, 1).Font.Italic = True
    wsDash.Cells(lastDashRow, 1).Font.Color = RGB(120, 120, 120)
    wsDash.Cells(lastDashRow, 1).HorizontalAlignment = xlHAlignCenter

    ' Auto-Fit Columns for Presentation Clarity
    wsDash.Columns("A:P").AutoFit
    wsDash.Activate

    MsgBox "OBDO Executive Dashboard successfully created!" & vbCrLf & _
           "Pivot tables were generated in isolated column blocks with a " & spacing & "-row dashboard buffer.", _
           vbInformation, "Dashboard Build Complete"

CleanUp:
    Application.DisplayAlerts = True
    Application.Calculation = xlCalculationAutomatic
    Application.ScreenUpdating = True
    Exit Sub

ErrorHandler:
    Application.DisplayAlerts = True
    Application.Calculation = xlCalculationAutomatic
    Application.ScreenUpdating = True
    MsgBox "An error occurred while generating the dashboard:" & vbCrLf & _
           Err.Description & " (Error #" & Err.Number & ")", vbCritical, "VBA Error"
End Sub

' Helper Function to Dynamically Search Column Headers
Private Function FindHeader(ws As Worksheet, ParamArray keywords() As Variant) As String
    Dim col As Long
    Dim lastCol As Long
    Dim cellVal As String
    Dim kw As Variant
    
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    For col = 1 To lastCol
        cellVal = Trim(ws.Cells(1, col).Value)
        For Each kw In keywords
            If InStr(1, cellVal, CStr(kw), vbTextCompare) > 0 Then
                FindHeader = cellVal
                Exit Function
            End If
        Next kw
    Next col
    FindHeader = ""
End Function

' Helper Function to Prevent Caption Name Collision with Source Fields (Error 1004)
Private Function SafeCaption(desiredCaption As String, sourceFieldName As String) As String
    If Trim(UCase(desiredCaption)) = Trim(UCase(sourceFieldName)) Then
        SafeCaption = desiredCaption & " " ' Append trailing space so Excel treats as unique
    Else
        SafeCaption = desiredCaption
    End If
End Function

' Helper Function to Sum a Dynamic Column
Private Function SumHeaderColumn(ws As Worksheet, headerName As String, lastRow As Long) As Double
    Dim col As Long
    If headerName = "" Or lastRow < 2 Then
        SumHeaderColumn = 0
        Exit Function
    End If
    On Error Resume Next
    col = ws.Rows(1).Find(What:=headerName, LookIn:=xlValues, LookAt:=xlWhole).Column
    If col > 0 Then
        SumHeaderColumn = Application.WorksheetFunction.Sum(ws.Range(ws.Cells(2, col), ws.Cells(lastRow, col)))
    Else
        SumHeaderColumn = 0
    End If
    On Error GoTo 0
End Function

' Helper Function to Get True Last Row Used Across ALL Columns
Private Function GetLastRowOnSheet(ws As Worksheet) As Long
    On Error Resume Next
    GetLastRowOnSheet = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, _
                        LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False).Row
    If Err.Number <> 0 Or GetLastRowOnSheet = 0 Then GetLastRowOnSheet = 1
    On Error GoTo 0
End Function

' Helper Subroutine for KPI Card Styling
Private Sub FormatKPICard(ws As Worksheet, cellRange As String, cardTitle As String, cardValueText As String, bgColor As Long, borderColor As Long)
    With ws.Range(cellRange)
        .Merge
        .Interior.Color = bgColor
        .Borders.Color = borderColor
        .Borders.Weight = xlMedium
        .HorizontalAlignment = xlHAlignCenter
        .VerticalAlignment = xlVAlignCenter
        .Value = cardTitle & vbCrLf & cardValueText
        .Font.Bold = True
        .Font.Name = "Calibri"
        .Font.Size = 11
        .WrapText = True
    End With
End Sub

' Daily Refresh Subroutine
Public Sub RefreshDashboardData()
    Dim pc As PivotCache
    On Error Resume Next
    For Each pc In ActiveWorkbook.PivotCaches
        pc.Refresh
    Next pc
    MsgBox "All OBDO Dashboard pivot tables refreshed with updated daily data!", vbInformation, "Refresh Complete"
End Sub
`;
}


